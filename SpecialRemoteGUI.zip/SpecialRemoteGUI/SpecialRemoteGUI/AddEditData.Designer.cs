﻿namespace SpecialRemoteGUI
{
    partial class AddEditData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddEditData));
            this.pnlAddEditTop = new System.Windows.Forms.Panel();
            this.lblAddEditTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnAddEditMinimize = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnAddEditClose = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.pnlAddEditMiddle = new System.Windows.Forms.Panel();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.pnlAddEditBottom = new System.Windows.Forms.Panel();
            this.btnAddEditCancel = new System.Windows.Forms.Button();
            this.btnAddEditOK = new System.Windows.Forms.Button();
            this.txtBaseE2Data = new System.Windows.Forms.TextBox();
            this.lblAddEditBaseData = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtE2Data = new System.Windows.Forms.TextBox();
            this.lblAddEditNewData = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtE2Address = new System.Windows.Forms.TextBox();
            this.lblAddEditAddr = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.lblAddEditTotal = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.cmbType = new System.Windows.Forms.ComboBox();
            this.lblAddEditType = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pnlAddEditTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddEditMinimize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddEditClose)).BeginInit();
            this.pnlAddEditMiddle.SuspendLayout();
            this.pnlAddEditBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlAddEditTop
            // 
            this.pnlAddEditTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.pnlAddEditTop.Controls.Add(this.lblAddEditTitle);
            this.pnlAddEditTop.Controls.Add(this.btnAddEditMinimize);
            this.pnlAddEditTop.Controls.Add(this.btnAddEditClose);
            this.pnlAddEditTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlAddEditTop.Location = new System.Drawing.Point(0, 0);
            this.pnlAddEditTop.Name = "pnlAddEditTop";
            this.pnlAddEditTop.Size = new System.Drawing.Size(305, 32);
            this.pnlAddEditTop.TabIndex = 0;
            // 
            // lblAddEditTitle
            // 
            this.lblAddEditTitle.AutoSize = true;
            this.lblAddEditTitle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddEditTitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAddEditTitle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAddEditTitle.Location = new System.Drawing.Point(100, 8);
            this.lblAddEditTitle.Name = "lblAddEditTitle";
            this.lblAddEditTitle.Size = new System.Drawing.Size(101, 17);
            this.lblAddEditTitle.TabIndex = 0;
            this.lblAddEditTitle.Text = "Add/Edit data";
            // 
            // btnAddEditMinimize
            // 
            this.btnAddEditMinimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnAddEditMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddEditMinimize.Image = ((System.Drawing.Image)(resources.GetObject("btnAddEditMinimize.Image")));
            this.btnAddEditMinimize.ImageActive = null;
            this.btnAddEditMinimize.Location = new System.Drawing.Point(251, 6);
            this.btnAddEditMinimize.Name = "btnAddEditMinimize";
            this.btnAddEditMinimize.Size = new System.Drawing.Size(20, 20);
            this.btnAddEditMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnAddEditMinimize.TabIndex = 9;
            this.btnAddEditMinimize.TabStop = false;
            this.btnAddEditMinimize.Zoom = 10;
            this.btnAddEditMinimize.Click += new System.EventHandler(this.btnAddEditMinimize_Click);
            // 
            // btnAddEditClose
            // 
            this.btnAddEditClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnAddEditClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddEditClose.Image = ((System.Drawing.Image)(resources.GetObject("btnAddEditClose.Image")));
            this.btnAddEditClose.ImageActive = null;
            this.btnAddEditClose.Location = new System.Drawing.Point(277, 6);
            this.btnAddEditClose.Name = "btnAddEditClose";
            this.btnAddEditClose.Size = new System.Drawing.Size(20, 20);
            this.btnAddEditClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnAddEditClose.TabIndex = 8;
            this.btnAddEditClose.TabStop = false;
            this.btnAddEditClose.Zoom = 10;
            this.btnAddEditClose.Click += new System.EventHandler(this.btnAddEditClose_Click);
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.lblAddEditTitle;
            this.bunifuDragControl1.Vertical = true;
            // 
            // pnlAddEditMiddle
            // 
            this.pnlAddEditMiddle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pnlAddEditMiddle.Controls.Add(this.bunifuSeparator1);
            this.pnlAddEditMiddle.Controls.Add(this.pnlAddEditBottom);
            this.pnlAddEditMiddle.Controls.Add(this.txtBaseE2Data);
            this.pnlAddEditMiddle.Controls.Add(this.lblAddEditBaseData);
            this.pnlAddEditMiddle.Controls.Add(this.txtE2Data);
            this.pnlAddEditMiddle.Controls.Add(this.lblAddEditNewData);
            this.pnlAddEditMiddle.Controls.Add(this.txtE2Address);
            this.pnlAddEditMiddle.Controls.Add(this.lblAddEditAddr);
            this.pnlAddEditMiddle.Controls.Add(this.txtTotal);
            this.pnlAddEditMiddle.Controls.Add(this.lblAddEditTotal);
            this.pnlAddEditMiddle.Controls.Add(this.cmbType);
            this.pnlAddEditMiddle.Controls.Add(this.lblAddEditType);
            this.pnlAddEditMiddle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAddEditMiddle.Location = new System.Drawing.Point(0, 32);
            this.pnlAddEditMiddle.Name = "pnlAddEditMiddle";
            this.pnlAddEditMiddle.Size = new System.Drawing.Size(305, 215);
            this.pnlAddEditMiddle.TabIndex = 0;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(-5, 154);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(302, 10);
            this.bunifuSeparator1.TabIndex = 0;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // pnlAddEditBottom
            // 
            this.pnlAddEditBottom.Controls.Add(this.btnAddEditCancel);
            this.pnlAddEditBottom.Controls.Add(this.btnAddEditOK);
            this.pnlAddEditBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlAddEditBottom.Location = new System.Drawing.Point(0, 154);
            this.pnlAddEditBottom.Name = "pnlAddEditBottom";
            this.pnlAddEditBottom.Size = new System.Drawing.Size(305, 61);
            this.pnlAddEditBottom.TabIndex = 1;
            // 
            // btnAddEditCancel
            // 
            this.btnAddEditCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnAddEditCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddEditCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAddEditCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddEditCancel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddEditCancel.ForeColor = System.Drawing.SystemColors.Control;
            this.btnAddEditCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnAddEditCancel.Image")));
            this.btnAddEditCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddEditCancel.Location = new System.Drawing.Point(83, 15);
            this.btnAddEditCancel.Name = "btnAddEditCancel";
            this.btnAddEditCancel.Size = new System.Drawing.Size(90, 34);
            this.btnAddEditCancel.TabIndex = 1;
            this.btnAddEditCancel.Text = "         Cancel";
            this.btnAddEditCancel.UseVisualStyleBackColor = false;
            this.btnAddEditCancel.Click += new System.EventHandler(this.btnAddEditCancel_Click);
            // 
            // btnAddEditOK
            // 
            this.btnAddEditOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnAddEditOK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddEditOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAddEditOK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddEditOK.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddEditOK.ForeColor = System.Drawing.SystemColors.Control;
            this.btnAddEditOK.Image = ((System.Drawing.Image)(resources.GetObject("btnAddEditOK.Image")));
            this.btnAddEditOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddEditOK.Location = new System.Drawing.Point(180, 14);
            this.btnAddEditOK.Name = "btnAddEditOK";
            this.btnAddEditOK.Size = new System.Drawing.Size(85, 36);
            this.btnAddEditOK.TabIndex = 0;
            this.btnAddEditOK.Text = "         OK";
            this.btnAddEditOK.UseVisualStyleBackColor = false;
            this.btnAddEditOK.Click += new System.EventHandler(this.btnAddEditOK_Click);
            // 
            // txtBaseE2Data
            // 
            this.txtBaseE2Data.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.txtBaseE2Data.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBaseE2Data.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtBaseE2Data.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBaseE2Data.ForeColor = System.Drawing.Color.White;
            this.txtBaseE2Data.Location = new System.Drawing.Point(101, 128);
            this.txtBaseE2Data.MaxLength = 2;
            this.txtBaseE2Data.Multiline = true;
            this.txtBaseE2Data.Name = "txtBaseE2Data";
            this.txtBaseE2Data.Size = new System.Drawing.Size(164, 20);
            this.txtBaseE2Data.TabIndex = 5;
            this.txtBaseE2Data.Leave += new System.EventHandler(this.txtBaseE2Data_Leave);
            // 
            // lblAddEditBaseData
            // 
            this.lblAddEditBaseData.AutoSize = true;
            this.lblAddEditBaseData.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddEditBaseData.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAddEditBaseData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAddEditBaseData.Location = new System.Drawing.Point(19, 129);
            this.lblAddEditBaseData.Name = "lblAddEditBaseData";
            this.lblAddEditBaseData.Size = new System.Drawing.Size(81, 17);
            this.lblAddEditBaseData.TabIndex = 0;
            this.lblAddEditBaseData.Text = "Base data :";
            // 
            // txtE2Data
            // 
            this.txtE2Data.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.txtE2Data.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtE2Data.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtE2Data.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtE2Data.ForeColor = System.Drawing.Color.White;
            this.txtE2Data.Location = new System.Drawing.Point(101, 102);
            this.txtE2Data.MaxLength = 2;
            this.txtE2Data.Multiline = true;
            this.txtE2Data.Name = "txtE2Data";
            this.txtE2Data.Size = new System.Drawing.Size(164, 20);
            this.txtE2Data.TabIndex = 4;
            this.txtE2Data.Leave += new System.EventHandler(this.txtE2Data_Leave);
            // 
            // lblAddEditNewData
            // 
            this.lblAddEditNewData.AutoSize = true;
            this.lblAddEditNewData.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddEditNewData.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAddEditNewData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAddEditNewData.Location = new System.Drawing.Point(19, 103);
            this.lblAddEditNewData.Name = "lblAddEditNewData";
            this.lblAddEditNewData.Size = new System.Drawing.Size(82, 17);
            this.lblAddEditNewData.TabIndex = 0;
            this.lblAddEditNewData.Text = "New data :";
            // 
            // txtE2Address
            // 
            this.txtE2Address.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.txtE2Address.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtE2Address.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtE2Address.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtE2Address.ForeColor = System.Drawing.Color.White;
            this.txtE2Address.Location = new System.Drawing.Point(101, 76);
            this.txtE2Address.MaxLength = 2;
            this.txtE2Address.Multiline = true;
            this.txtE2Address.Name = "txtE2Address";
            this.txtE2Address.Size = new System.Drawing.Size(164, 20);
            this.txtE2Address.TabIndex = 3;
            this.txtE2Address.Leave += new System.EventHandler(this.txtE2Address_Leave);
            // 
            // lblAddEditAddr
            // 
            this.lblAddEditAddr.AutoSize = true;
            this.lblAddEditAddr.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddEditAddr.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAddEditAddr.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAddEditAddr.Location = new System.Drawing.Point(19, 77);
            this.lblAddEditAddr.Name = "lblAddEditAddr";
            this.lblAddEditAddr.Size = new System.Drawing.Size(65, 17);
            this.lblAddEditAddr.TabIndex = 0;
            this.lblAddEditAddr.Text = "Address :";
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.txtTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTotal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtTotal.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.ForeColor = System.Drawing.Color.White;
            this.txtTotal.Location = new System.Drawing.Point(101, 50);
            this.txtTotal.MaxLength = 2;
            this.txtTotal.Multiline = true;
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(164, 20);
            this.txtTotal.TabIndex = 2;
            this.txtTotal.Leave += new System.EventHandler(this.txtTotal_Leave);
            // 
            // lblAddEditTotal
            // 
            this.lblAddEditTotal.AutoSize = true;
            this.lblAddEditTotal.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddEditTotal.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAddEditTotal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAddEditTotal.Location = new System.Drawing.Point(19, 51);
            this.lblAddEditTotal.Name = "lblAddEditTotal";
            this.lblAddEditTotal.Size = new System.Drawing.Size(47, 17);
            this.lblAddEditTotal.TabIndex = 0;
            this.lblAddEditTotal.Text = "Total :";
            // 
            // cmbType
            // 
            this.cmbType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.cmbType.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbType.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbType.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbType.FormattingEnabled = true;
            this.cmbType.Items.AddRange(new object[] {
            "FCU",
            "CDU"});
            this.cmbType.Location = new System.Drawing.Point(101, 17);
            this.cmbType.Name = "cmbType";
            this.cmbType.Size = new System.Drawing.Size(164, 26);
            this.cmbType.TabIndex = 1;
            // 
            // lblAddEditType
            // 
            this.lblAddEditType.AutoSize = true;
            this.lblAddEditType.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddEditType.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAddEditType.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAddEditType.Location = new System.Drawing.Point(22, 19);
            this.lblAddEditType.Name = "lblAddEditType";
            this.lblAddEditType.Size = new System.Drawing.Size(44, 17);
            this.lblAddEditType.TabIndex = 0;
            this.lblAddEditType.Text = "Type :";
            // 
            // AddEditData
            // 
            this.AcceptButton = this.btnAddEditOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(305, 247);
            this.Controls.Add(this.pnlAddEditMiddle);
            this.Controls.Add(this.pnlAddEditTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddEditData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "AddEditData";
            this.Load += new System.EventHandler(this.AddEditData_Load);
            this.pnlAddEditTop.ResumeLayout(false);
            this.pnlAddEditTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddEditMinimize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddEditClose)).EndInit();
            this.pnlAddEditMiddle.ResumeLayout(false);
            this.pnlAddEditMiddle.PerformLayout();
            this.pnlAddEditBottom.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAddEditTop;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.Panel pnlAddEditMiddle;
        private Bunifu.Framework.UI.BunifuCustomLabel lblAddEditTitle;
        private Bunifu.Framework.UI.BunifuImageButton btnAddEditMinimize;
        private Bunifu.Framework.UI.BunifuImageButton btnAddEditClose;
        private Bunifu.Framework.UI.BunifuCustomLabel lblAddEditType;
        private Bunifu.Framework.UI.BunifuCustomLabel lblAddEditTotal;
        private System.Windows.Forms.ComboBox cmbType;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txtBaseE2Data;
        private Bunifu.Framework.UI.BunifuCustomLabel lblAddEditBaseData;
        private System.Windows.Forms.TextBox txtE2Data;
        private Bunifu.Framework.UI.BunifuCustomLabel lblAddEditNewData;
        private System.Windows.Forms.TextBox txtE2Address;
        private Bunifu.Framework.UI.BunifuCustomLabel lblAddEditAddr;
        private System.Windows.Forms.Panel pnlAddEditBottom;
        private System.Windows.Forms.Button btnAddEditCancel;
        private System.Windows.Forms.Button btnAddEditOK;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
    }
}