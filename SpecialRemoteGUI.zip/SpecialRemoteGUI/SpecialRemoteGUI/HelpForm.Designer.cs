﻿namespace SpecialRemoteGUI
{
    partial class HelpForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HelpForm));
            this.stepWizardControl1 = new AeroWizard.StepWizardControl();
            this.wizardPage1 = new AeroWizard.WizardPage();
            this.pictureBoxHelp1 = new System.Windows.Forms.PictureBox();
            this.wizardPage2 = new AeroWizard.WizardPage();
            this.pictureBoxHelp2 = new System.Windows.Forms.PictureBox();
            this.wizardPage3 = new AeroWizard.WizardPage();
            this.pictureBoxHelp3 = new System.Windows.Forms.PictureBox();
            this.wizardPage4 = new AeroWizard.WizardPage();
            this.pictureBoxHelp4 = new System.Windows.Forms.PictureBox();
            this.wizardPage5 = new AeroWizard.WizardPage();
            this.pictureBoxHelp5 = new System.Windows.Forms.PictureBox();
            this.lblHelpWriteWindow = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.stepWizardControl1)).BeginInit();
            this.wizardPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHelp1)).BeginInit();
            this.wizardPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHelp2)).BeginInit();
            this.wizardPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHelp3)).BeginInit();
            this.wizardPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHelp4)).BeginInit();
            this.wizardPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHelp5)).BeginInit();
            this.SuspendLayout();
            // 
            // stepWizardControl1
            // 
            this.stepWizardControl1.BackColor = System.Drawing.Color.White;
            this.stepWizardControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.stepWizardControl1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stepWizardControl1.Location = new System.Drawing.Point(0, 0);
            this.stepWizardControl1.Name = "stepWizardControl1";
            this.stepWizardControl1.Pages.Add(this.wizardPage1);
            this.stepWizardControl1.Pages.Add(this.wizardPage2);
            this.stepWizardControl1.Pages.Add(this.wizardPage3);
            this.stepWizardControl1.Pages.Add(this.wizardPage4);
            this.stepWizardControl1.Pages.Add(this.wizardPage5);
            this.stepWizardControl1.Size = new System.Drawing.Size(800, 450);
            this.stepWizardControl1.StepListFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.stepWizardControl1.TabIndex = 0;
            this.stepWizardControl1.Text = "Help";
            this.stepWizardControl1.Title = "Help";
            this.stepWizardControl1.TitleIcon = ((System.Drawing.Icon)(resources.GetObject("stepWizardControl1.TitleIcon")));
            // 
            // wizardPage1
            // 
            this.wizardPage1.Controls.Add(this.lblHelpWriteWindow);
            this.wizardPage1.Controls.Add(this.pictureBoxHelp1);
            this.wizardPage1.Name = "wizardPage1";
            this.wizardPage1.Size = new System.Drawing.Size(602, 296);
            this.stepWizardControl1.SetStepText(this.wizardPage1, "Load data file");
            this.wizardPage1.TabIndex = 2;
            this.wizardPage1.Text = "Dashboard";
            // 
            // pictureBoxHelp1
            // 
            this.pictureBoxHelp1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxHelp1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp1.Image")));
            this.pictureBoxHelp1.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxHelp1.Name = "pictureBoxHelp1";
            this.pictureBoxHelp1.Size = new System.Drawing.Size(602, 296);
            this.pictureBoxHelp1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxHelp1.TabIndex = 1;
            this.pictureBoxHelp1.TabStop = false;
            // 
            // wizardPage2
            // 
            this.wizardPage2.Controls.Add(this.pictureBoxHelp2);
            this.wizardPage2.Name = "wizardPage2";
            this.wizardPage2.Size = new System.Drawing.Size(602, 296);
            this.stepWizardControl1.SetStepText(this.wizardPage2, "Manual edit");
            this.wizardPage2.TabIndex = 3;
            this.wizardPage2.Text = "Dashboard";
            // 
            // pictureBoxHelp2
            // 
            this.pictureBoxHelp2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxHelp2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp2.Image")));
            this.pictureBoxHelp2.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxHelp2.Name = "pictureBoxHelp2";
            this.pictureBoxHelp2.Size = new System.Drawing.Size(602, 296);
            this.pictureBoxHelp2.TabIndex = 1;
            this.pictureBoxHelp2.TabStop = false;
            // 
            // wizardPage3
            // 
            this.wizardPage3.Controls.Add(this.pictureBoxHelp3);
            this.wizardPage3.Name = "wizardPage3";
            this.wizardPage3.Size = new System.Drawing.Size(602, 296);
            this.stepWizardControl1.SetStepText(this.wizardPage3, "Serial port");
            this.wizardPage3.TabIndex = 4;
            this.wizardPage3.Text = "Setting";
            // 
            // pictureBoxHelp3
            // 
            this.pictureBoxHelp3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxHelp3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp3.Image")));
            this.pictureBoxHelp3.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxHelp3.Name = "pictureBoxHelp3";
            this.pictureBoxHelp3.Size = new System.Drawing.Size(602, 296);
            this.pictureBoxHelp3.TabIndex = 1;
            this.pictureBoxHelp3.TabStop = false;
            // 
            // wizardPage4
            // 
            this.wizardPage4.Controls.Add(this.pictureBoxHelp4);
            this.wizardPage4.Name = "wizardPage4";
            this.wizardPage4.Size = new System.Drawing.Size(602, 296);
            this.stepWizardControl1.SetStepText(this.wizardPage4, "Manual program");
            this.wizardPage4.TabIndex = 5;
            this.wizardPage4.Text = "Control";
            // 
            // pictureBoxHelp4
            // 
            this.pictureBoxHelp4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxHelp4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp4.Image")));
            this.pictureBoxHelp4.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxHelp4.Name = "pictureBoxHelp4";
            this.pictureBoxHelp4.Size = new System.Drawing.Size(602, 296);
            this.pictureBoxHelp4.TabIndex = 1;
            this.pictureBoxHelp4.TabStop = false;
            // 
            // wizardPage5
            // 
            this.wizardPage5.Controls.Add(this.pictureBoxHelp5);
            this.wizardPage5.Name = "wizardPage5";
            this.wizardPage5.Size = new System.Drawing.Size(602, 296);
            this.stepWizardControl1.SetStepText(this.wizardPage5, "Auto program");
            this.wizardPage5.TabIndex = 6;
            this.wizardPage5.Text = "Control";
            // 
            // pictureBoxHelp5
            // 
            this.pictureBoxHelp5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxHelp5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHelp5.Image")));
            this.pictureBoxHelp5.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxHelp5.Name = "pictureBoxHelp5";
            this.pictureBoxHelp5.Size = new System.Drawing.Size(602, 296);
            this.pictureBoxHelp5.TabIndex = 1;
            this.pictureBoxHelp5.TabStop = false;
            // 
            // lblHelpWriteWindow
            // 
            this.lblHelpWriteWindow.AutoSize = true;
            this.lblHelpWriteWindow.BackColor = System.Drawing.SystemColors.MenuText;
            this.lblHelpWriteWindow.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHelpWriteWindow.ForeColor = System.Drawing.Color.White;
            this.lblHelpWriteWindow.Location = new System.Drawing.Point(175, 187);
            this.lblHelpWriteWindow.Name = "lblHelpWriteWindow";
            this.lblHelpWriteWindow.Size = new System.Drawing.Size(90, 17);
            this.lblHelpWriteWindow.TabIndex = 1;
            this.lblHelpWriteWindow.Text = "Write window";
            // 
            // HelpForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.stepWizardControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "HelpForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "HelpForm";
            ((System.ComponentModel.ISupportInitialize)(this.stepWizardControl1)).EndInit();
            this.wizardPage1.ResumeLayout(false);
            this.wizardPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHelp1)).EndInit();
            this.wizardPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHelp2)).EndInit();
            this.wizardPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHelp3)).EndInit();
            this.wizardPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHelp4)).EndInit();
            this.wizardPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHelp5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AeroWizard.StepWizardControl stepWizardControl1;
        private AeroWizard.WizardPage wizardPage1;
        private System.Windows.Forms.PictureBox pictureBoxHelp1;
        private AeroWizard.WizardPage wizardPage2;
        private System.Windows.Forms.PictureBox pictureBoxHelp2;
        private AeroWizard.WizardPage wizardPage3;
        private AeroWizard.WizardPage wizardPage4;
        private AeroWizard.WizardPage wizardPage5;
        private System.Windows.Forms.PictureBox pictureBoxHelp3;
        private System.Windows.Forms.PictureBox pictureBoxHelp4;
        private System.Windows.Forms.PictureBox pictureBoxHelp5;
        private System.Windows.Forms.Label lblHelpWriteWindow;
    }
}