﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SpecialRemoteGUI
{
    public partial class Message : Form
    {
        public enum type
        {
            success = 0,
            error,
            info,
            warning
        }

        public Message(string message, type t)
        {
            InitializeComponent();
            lblShortMessage.Text = message;
            switch (t)
            {
                case type.success:
                    btnMessageIcon.BringToFront();
                    break;
                case type.error:
                    btnMessageIconError.BringToFront();
                    break;
                case type.info:
                    btnMessageIconInfo.BringToFront();
                    break;
                case type.warning:
                    btnMessageIconInfo.BringToFront();
                    break;
                default:
                    break;
            }
        }

        private void Message_Load(object sender, EventArgs e)
        {
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnMessageClose_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
