﻿namespace SpecialRemoteGUI
{
    partial class SettingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingForm));
            this.pnlSettingTop = new System.Windows.Forms.Panel();
            this.lblSettingTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnSettingMinimize = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnSettingClose = new Bunifu.Framework.UI.BunifuImageButton();
            this.pnlSettingLeft = new System.Windows.Forms.Panel();
            this.btnSettingDbg = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnSettingAuto = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnSerialPortSetting = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnSettingMenu = new Bunifu.Framework.UI.BunifuImageButton();
            this.pnlSettingSerial = new System.Windows.Forms.Panel();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.cmbSettingStopBit = new System.Windows.Forms.ComboBox();
            this.cmbSettingParity = new System.Windows.Forms.ComboBox();
            this.cmbSettingDataBits = new System.Windows.Forms.ComboBox();
            this.cmbSettingBaudrate = new System.Windows.Forms.ComboBox();
            this.cmbSettingComPort = new System.Windows.Forms.ComboBox();
            this.btnRefreshPort = new Bunifu.Framework.UI.BunifuFlatButton();
            this.lblStopbit = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblParity = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblDatabit = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblBaudrate = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblComport = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblSettingSerialPort = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pnlSettingBottom = new System.Windows.Forms.Panel();
            this.bunifuSeparator4 = new Bunifu.Framework.UI.BunifuSeparator();
            this.btnSettingCancel = new System.Windows.Forms.Button();
            this.btnSettingOK = new System.Windows.Forms.Button();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.pnlSettingAutoMode = new System.Windows.Forms.Panel();
            this.lblAutoSeqEnable = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkbAutoSeqEna = new Bunifu.Framework.UI.BunifuiOSSwitch();
            this.checkedListBox = new System.Windows.Forms.CheckedListBox();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.lblSettingAutoMode = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pnlSettingDbg = new System.Windows.Forms.Panel();
            this.lblDbgModeEnabled = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chbDbgModeEnable = new Bunifu.Framework.UI.BunifuiOSSwitch();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.lblSettingDebug = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pnlSettingTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnSettingMinimize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSettingClose)).BeginInit();
            this.pnlSettingLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnSettingMenu)).BeginInit();
            this.pnlSettingSerial.SuspendLayout();
            this.pnlSettingBottom.SuspendLayout();
            this.pnlSettingAutoMode.SuspendLayout();
            this.pnlSettingDbg.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlSettingTop
            // 
            this.pnlSettingTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.pnlSettingTop.Controls.Add(this.lblSettingTitle);
            this.pnlSettingTop.Controls.Add(this.btnSettingMinimize);
            this.pnlSettingTop.Controls.Add(this.btnSettingClose);
            this.pnlSettingTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSettingTop.Location = new System.Drawing.Point(0, 0);
            this.pnlSettingTop.Name = "pnlSettingTop";
            this.pnlSettingTop.Size = new System.Drawing.Size(354, 26);
            this.pnlSettingTop.TabIndex = 0;
            // 
            // lblSettingTitle
            // 
            this.lblSettingTitle.AutoSize = true;
            this.lblSettingTitle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSettingTitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSettingTitle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSettingTitle.Location = new System.Drawing.Point(151, 4);
            this.lblSettingTitle.Name = "lblSettingTitle";
            this.lblSettingTitle.Size = new System.Drawing.Size(52, 17);
            this.lblSettingTitle.TabIndex = 7;
            this.lblSettingTitle.Text = "Setting";
            // 
            // btnSettingMinimize
            // 
            this.btnSettingMinimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnSettingMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingMinimize.Image = ((System.Drawing.Image)(resources.GetObject("btnSettingMinimize.Image")));
            this.btnSettingMinimize.ImageActive = null;
            this.btnSettingMinimize.Location = new System.Drawing.Point(294, 3);
            this.btnSettingMinimize.Name = "btnSettingMinimize";
            this.btnSettingMinimize.Size = new System.Drawing.Size(20, 20);
            this.btnSettingMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnSettingMinimize.TabIndex = 4;
            this.btnSettingMinimize.TabStop = false;
            this.btnSettingMinimize.Zoom = 10;
            this.btnSettingMinimize.Click += new System.EventHandler(this.btnSettingMinimize_Click);
            // 
            // btnSettingClose
            // 
            this.btnSettingClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnSettingClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingClose.Image = ((System.Drawing.Image)(resources.GetObject("btnSettingClose.Image")));
            this.btnSettingClose.ImageActive = null;
            this.btnSettingClose.Location = new System.Drawing.Point(320, 3);
            this.btnSettingClose.Name = "btnSettingClose";
            this.btnSettingClose.Size = new System.Drawing.Size(20, 20);
            this.btnSettingClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnSettingClose.TabIndex = 3;
            this.btnSettingClose.TabStop = false;
            this.btnSettingClose.Zoom = 10;
            this.btnSettingClose.Click += new System.EventHandler(this.btnSettingClose_Click);
            // 
            // pnlSettingLeft
            // 
            this.pnlSettingLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pnlSettingLeft.Controls.Add(this.btnSettingDbg);
            this.pnlSettingLeft.Controls.Add(this.btnSettingAuto);
            this.pnlSettingLeft.Controls.Add(this.btnSerialPortSetting);
            this.pnlSettingLeft.Controls.Add(this.btnSettingMenu);
            this.pnlSettingLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlSettingLeft.Location = new System.Drawing.Point(0, 26);
            this.pnlSettingLeft.Name = "pnlSettingLeft";
            this.pnlSettingLeft.Size = new System.Drawing.Size(36, 202);
            this.pnlSettingLeft.TabIndex = 1;
            // 
            // btnSettingDbg
            // 
            this.btnSettingDbg.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnSettingDbg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnSettingDbg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSettingDbg.BorderRadius = 0;
            this.btnSettingDbg.ButtonText = "  Debug";
            this.btnSettingDbg.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingDbg.DisabledColor = System.Drawing.Color.Gray;
            this.btnSettingDbg.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSettingDbg.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnSettingDbg.Iconimage")));
            this.btnSettingDbg.Iconimage_right = null;
            this.btnSettingDbg.Iconimage_right_Selected = null;
            this.btnSettingDbg.Iconimage_Selected = null;
            this.btnSettingDbg.IconMarginLeft = 0;
            this.btnSettingDbg.IconMarginRight = 0;
            this.btnSettingDbg.IconRightVisible = true;
            this.btnSettingDbg.IconRightZoom = 0D;
            this.btnSettingDbg.IconVisible = true;
            this.btnSettingDbg.IconZoom = 50D;
            this.btnSettingDbg.IsTab = false;
            this.btnSettingDbg.Location = new System.Drawing.Point(2, 111);
            this.btnSettingDbg.Name = "btnSettingDbg";
            this.btnSettingDbg.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnSettingDbg.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(102)))), ((int)(((byte)(0)))));
            this.btnSettingDbg.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSettingDbg.selected = false;
            this.btnSettingDbg.Size = new System.Drawing.Size(109, 29);
            this.btnSettingDbg.TabIndex = 23;
            this.btnSettingDbg.Text = "  Debug";
            this.btnSettingDbg.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettingDbg.Textcolor = System.Drawing.Color.White;
            this.btnSettingDbg.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingDbg.Click += new System.EventHandler(this.btnSettingDbg_Click);
            // 
            // btnSettingAuto
            // 
            this.btnSettingAuto.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnSettingAuto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnSettingAuto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSettingAuto.BorderRadius = 0;
            this.btnSettingAuto.ButtonText = "  Auto";
            this.btnSettingAuto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingAuto.DisabledColor = System.Drawing.Color.Gray;
            this.btnSettingAuto.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSettingAuto.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnSettingAuto.Iconimage")));
            this.btnSettingAuto.Iconimage_right = null;
            this.btnSettingAuto.Iconimage_right_Selected = null;
            this.btnSettingAuto.Iconimage_Selected = null;
            this.btnSettingAuto.IconMarginLeft = 0;
            this.btnSettingAuto.IconMarginRight = 0;
            this.btnSettingAuto.IconRightVisible = true;
            this.btnSettingAuto.IconRightZoom = 0D;
            this.btnSettingAuto.IconVisible = true;
            this.btnSettingAuto.IconZoom = 50D;
            this.btnSettingAuto.IsTab = false;
            this.btnSettingAuto.Location = new System.Drawing.Point(1, 76);
            this.btnSettingAuto.Name = "btnSettingAuto";
            this.btnSettingAuto.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnSettingAuto.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(102)))), ((int)(((byte)(0)))));
            this.btnSettingAuto.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSettingAuto.selected = false;
            this.btnSettingAuto.Size = new System.Drawing.Size(111, 29);
            this.btnSettingAuto.TabIndex = 22;
            this.btnSettingAuto.Text = "  Auto";
            this.btnSettingAuto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettingAuto.Textcolor = System.Drawing.Color.White;
            this.btnSettingAuto.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingAuto.Click += new System.EventHandler(this.btnSettingAuto_Click);
            // 
            // btnSerialPortSetting
            // 
            this.btnSerialPortSetting.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnSerialPortSetting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnSerialPortSetting.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSerialPortSetting.BorderRadius = 0;
            this.btnSerialPortSetting.ButtonText = "  Serial port";
            this.btnSerialPortSetting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSerialPortSetting.DisabledColor = System.Drawing.Color.Gray;
            this.btnSerialPortSetting.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSerialPortSetting.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnSerialPortSetting.Iconimage")));
            this.btnSerialPortSetting.Iconimage_right = null;
            this.btnSerialPortSetting.Iconimage_right_Selected = null;
            this.btnSerialPortSetting.Iconimage_Selected = null;
            this.btnSerialPortSetting.IconMarginLeft = 0;
            this.btnSerialPortSetting.IconMarginRight = 0;
            this.btnSerialPortSetting.IconRightVisible = true;
            this.btnSerialPortSetting.IconRightZoom = 0D;
            this.btnSerialPortSetting.IconVisible = true;
            this.btnSerialPortSetting.IconZoom = 50D;
            this.btnSerialPortSetting.IsTab = false;
            this.btnSerialPortSetting.Location = new System.Drawing.Point(3, 41);
            this.btnSerialPortSetting.Name = "btnSerialPortSetting";
            this.btnSerialPortSetting.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnSerialPortSetting.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(102)))), ((int)(((byte)(0)))));
            this.btnSerialPortSetting.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSerialPortSetting.selected = false;
            this.btnSerialPortSetting.Size = new System.Drawing.Size(109, 29);
            this.btnSerialPortSetting.TabIndex = 21;
            this.btnSerialPortSetting.Text = "  Serial port";
            this.btnSerialPortSetting.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSerialPortSetting.Textcolor = System.Drawing.Color.White;
            this.btnSerialPortSetting.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSerialPortSetting.Click += new System.EventHandler(this.btnSerialPortSetting_Click);
            // 
            // btnSettingMenu
            // 
            this.btnSettingMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnSettingMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSettingMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingMenu.Image = ((System.Drawing.Image)(resources.GetObject("btnSettingMenu.Image")));
            this.btnSettingMenu.ImageActive = null;
            this.btnSettingMenu.Location = new System.Drawing.Point(1, 8);
            this.btnSettingMenu.Name = "btnSettingMenu";
            this.btnSettingMenu.Size = new System.Drawing.Size(29, 27);
            this.btnSettingMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnSettingMenu.TabIndex = 20;
            this.btnSettingMenu.TabStop = false;
            this.btnSettingMenu.Zoom = 10;
            this.btnSettingMenu.Click += new System.EventHandler(this.btnSettingMenu_Click);
            // 
            // pnlSettingSerial
            // 
            this.pnlSettingSerial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pnlSettingSerial.Controls.Add(this.bunifuSeparator3);
            this.pnlSettingSerial.Controls.Add(this.cmbSettingStopBit);
            this.pnlSettingSerial.Controls.Add(this.cmbSettingParity);
            this.pnlSettingSerial.Controls.Add(this.cmbSettingDataBits);
            this.pnlSettingSerial.Controls.Add(this.cmbSettingBaudrate);
            this.pnlSettingSerial.Controls.Add(this.cmbSettingComPort);
            this.pnlSettingSerial.Controls.Add(this.btnRefreshPort);
            this.pnlSettingSerial.Controls.Add(this.lblStopbit);
            this.pnlSettingSerial.Controls.Add(this.lblParity);
            this.pnlSettingSerial.Controls.Add(this.lblDatabit);
            this.pnlSettingSerial.Controls.Add(this.lblBaudrate);
            this.pnlSettingSerial.Controls.Add(this.lblComport);
            this.pnlSettingSerial.Controls.Add(this.lblSettingSerialPort);
            this.pnlSettingSerial.Location = new System.Drawing.Point(36, 26);
            this.pnlSettingSerial.Name = "pnlSettingSerial";
            this.pnlSettingSerial.Size = new System.Drawing.Size(318, 202);
            this.pnlSettingSerial.TabIndex = 2;
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.bunifuSeparator3.LineThickness = 1;
            this.bunifuSeparator3.Location = new System.Drawing.Point(0, 2);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(10, 240);
            this.bunifuSeparator3.TabIndex = 3;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = true;
            // 
            // cmbSettingStopBit
            // 
            this.cmbSettingStopBit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.cmbSettingStopBit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSettingStopBit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSettingStopBit.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSettingStopBit.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbSettingStopBit.FormattingEnabled = true;
            this.cmbSettingStopBit.Items.AddRange(new object[] {
            "One",
            "OnePointFive",
            "Two"});
            this.cmbSettingStopBit.Location = new System.Drawing.Point(115, 164);
            this.cmbSettingStopBit.Name = "cmbSettingStopBit";
            this.cmbSettingStopBit.Size = new System.Drawing.Size(164, 24);
            this.cmbSettingStopBit.TabIndex = 19;
            // 
            // cmbSettingParity
            // 
            this.cmbSettingParity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.cmbSettingParity.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSettingParity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSettingParity.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSettingParity.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbSettingParity.FormattingEnabled = true;
            this.cmbSettingParity.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even"});
            this.cmbSettingParity.Location = new System.Drawing.Point(115, 134);
            this.cmbSettingParity.Name = "cmbSettingParity";
            this.cmbSettingParity.Size = new System.Drawing.Size(164, 24);
            this.cmbSettingParity.TabIndex = 18;
            // 
            // cmbSettingDataBits
            // 
            this.cmbSettingDataBits.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.cmbSettingDataBits.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSettingDataBits.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSettingDataBits.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSettingDataBits.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbSettingDataBits.FormattingEnabled = true;
            this.cmbSettingDataBits.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
            this.cmbSettingDataBits.Location = new System.Drawing.Point(115, 104);
            this.cmbSettingDataBits.Name = "cmbSettingDataBits";
            this.cmbSettingDataBits.Size = new System.Drawing.Size(164, 24);
            this.cmbSettingDataBits.TabIndex = 17;
            // 
            // cmbSettingBaudrate
            // 
            this.cmbSettingBaudrate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.cmbSettingBaudrate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSettingBaudrate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSettingBaudrate.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSettingBaudrate.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbSettingBaudrate.FormattingEnabled = true;
            this.cmbSettingBaudrate.Items.AddRange(new object[] {
            "300",
            "600",
            "1200",
            "2400",
            "4800",
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200",
            "230400",
            "460800",
            "921600"});
            this.cmbSettingBaudrate.Location = new System.Drawing.Point(115, 74);
            this.cmbSettingBaudrate.Name = "cmbSettingBaudrate";
            this.cmbSettingBaudrate.Size = new System.Drawing.Size(164, 24);
            this.cmbSettingBaudrate.TabIndex = 16;
            // 
            // cmbSettingComPort
            // 
            this.cmbSettingComPort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.cmbSettingComPort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSettingComPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSettingComPort.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSettingComPort.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbSettingComPort.FormattingEnabled = true;
            this.cmbSettingComPort.Location = new System.Drawing.Point(115, 44);
            this.cmbSettingComPort.Name = "cmbSettingComPort";
            this.cmbSettingComPort.Size = new System.Drawing.Size(164, 24);
            this.cmbSettingComPort.TabIndex = 15;
            // 
            // btnRefreshPort
            // 
            this.btnRefreshPort.Activecolor = System.Drawing.Color.Lime;
            this.btnRefreshPort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnRefreshPort.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRefreshPort.BorderRadius = 0;
            this.btnRefreshPort.ButtonText = "";
            this.btnRefreshPort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefreshPort.DisabledColor = System.Drawing.Color.Gray;
            this.btnRefreshPort.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshPort.Iconcolor = System.Drawing.Color.Transparent;
            this.btnRefreshPort.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnRefreshPort.Iconimage")));
            this.btnRefreshPort.Iconimage_right = null;
            this.btnRefreshPort.Iconimage_right_Selected = null;
            this.btnRefreshPort.Iconimage_Selected = null;
            this.btnRefreshPort.IconMarginLeft = 0;
            this.btnRefreshPort.IconMarginRight = 0;
            this.btnRefreshPort.IconRightVisible = true;
            this.btnRefreshPort.IconRightZoom = 0D;
            this.btnRefreshPort.IconVisible = true;
            this.btnRefreshPort.IconZoom = 50D;
            this.btnRefreshPort.IsTab = false;
            this.btnRefreshPort.Location = new System.Drawing.Point(115, 6);
            this.btnRefreshPort.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRefreshPort.Name = "btnRefreshPort";
            this.btnRefreshPort.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnRefreshPort.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(102)))), ((int)(((byte)(0)))));
            this.btnRefreshPort.OnHoverTextColor = System.Drawing.Color.White;
            this.btnRefreshPort.selected = false;
            this.btnRefreshPort.Size = new System.Drawing.Size(35, 32);
            this.btnRefreshPort.TabIndex = 14;
            this.btnRefreshPort.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefreshPort.Textcolor = System.Drawing.Color.White;
            this.btnRefreshPort.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshPort.Click += new System.EventHandler(this.btnRefreshPort_Click);
            // 
            // lblStopbit
            // 
            this.lblStopbit.AutoSize = true;
            this.lblStopbit.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStopbit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblStopbit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblStopbit.Location = new System.Drawing.Point(27, 166);
            this.lblStopbit.Name = "lblStopbit";
            this.lblStopbit.Size = new System.Drawing.Size(71, 17);
            this.lblStopbit.TabIndex = 13;
            this.lblStopbit.Text = "Stop bits :";
            // 
            // lblParity
            // 
            this.lblParity.AutoSize = true;
            this.lblParity.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParity.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblParity.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblParity.Location = new System.Drawing.Point(27, 136);
            this.lblParity.Name = "lblParity";
            this.lblParity.Size = new System.Drawing.Size(51, 17);
            this.lblParity.TabIndex = 12;
            this.lblParity.Text = "Parity :";
            // 
            // lblDatabit
            // 
            this.lblDatabit.AutoSize = true;
            this.lblDatabit.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatabit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDatabit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDatabit.Location = new System.Drawing.Point(27, 106);
            this.lblDatabit.Name = "lblDatabit";
            this.lblDatabit.Size = new System.Drawing.Size(75, 17);
            this.lblDatabit.TabIndex = 11;
            this.lblDatabit.Text = "Data bits :";
            // 
            // lblBaudrate
            // 
            this.lblBaudrate.AutoSize = true;
            this.lblBaudrate.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaudrate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblBaudrate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblBaudrate.Location = new System.Drawing.Point(27, 76);
            this.lblBaudrate.Name = "lblBaudrate";
            this.lblBaudrate.Size = new System.Drawing.Size(75, 17);
            this.lblBaudrate.TabIndex = 10;
            this.lblBaudrate.Text = "Baudrate :";
            // 
            // lblComport
            // 
            this.lblComport.AutoSize = true;
            this.lblComport.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComport.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblComport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblComport.Location = new System.Drawing.Point(27, 46);
            this.lblComport.Name = "lblComport";
            this.lblComport.Size = new System.Drawing.Size(80, 17);
            this.lblComport.TabIndex = 9;
            this.lblComport.Text = "Com port :";
            // 
            // lblSettingSerialPort
            // 
            this.lblSettingSerialPort.AutoSize = true;
            this.lblSettingSerialPort.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSettingSerialPort.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSettingSerialPort.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSettingSerialPort.Location = new System.Drawing.Point(27, 19);
            this.lblSettingSerialPort.Name = "lblSettingSerialPort";
            this.lblSettingSerialPort.Size = new System.Drawing.Size(72, 17);
            this.lblSettingSerialPort.TabIndex = 8;
            this.lblSettingSerialPort.Text = "Serial port";
            // 
            // pnlSettingBottom
            // 
            this.pnlSettingBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pnlSettingBottom.Controls.Add(this.bunifuSeparator4);
            this.pnlSettingBottom.Controls.Add(this.btnSettingCancel);
            this.pnlSettingBottom.Controls.Add(this.btnSettingOK);
            this.pnlSettingBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlSettingBottom.Location = new System.Drawing.Point(0, 228);
            this.pnlSettingBottom.Name = "pnlSettingBottom";
            this.pnlSettingBottom.Size = new System.Drawing.Size(354, 52);
            this.pnlSettingBottom.TabIndex = 6;
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.bunifuSeparator4.LineThickness = 1;
            this.bunifuSeparator4.Location = new System.Drawing.Point(-4, -3);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(354, 10);
            this.bunifuSeparator4.TabIndex = 12;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = false;
            // 
            // btnSettingCancel
            // 
            this.btnSettingCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnSettingCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnSettingCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSettingCancel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingCancel.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSettingCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnSettingCancel.Image")));
            this.btnSettingCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettingCancel.Location = new System.Drawing.Point(134, 10);
            this.btnSettingCancel.Name = "btnSettingCancel";
            this.btnSettingCancel.Size = new System.Drawing.Size(89, 34);
            this.btnSettingCancel.TabIndex = 17;
            this.btnSettingCancel.Text = "         Cancel";
            this.btnSettingCancel.UseVisualStyleBackColor = false;
            this.btnSettingCancel.Click += new System.EventHandler(this.btnSettingCancel_Click);
            // 
            // btnSettingOK
            // 
            this.btnSettingOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnSettingOK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSettingOK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSettingOK.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingOK.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSettingOK.Image = ((System.Drawing.Image)(resources.GetObject("btnSettingOK.Image")));
            this.btnSettingOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettingOK.Location = new System.Drawing.Point(230, 9);
            this.btnSettingOK.Name = "btnSettingOK";
            this.btnSettingOK.Size = new System.Drawing.Size(85, 36);
            this.btnSettingOK.TabIndex = 6;
            this.btnSettingOK.Text = "         OK";
            this.btnSettingOK.UseVisualStyleBackColor = false;
            this.btnSettingOK.Click += new System.EventHandler(this.btnSettingOK_Click);
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.pnlSettingTop;
            this.bunifuDragControl1.Vertical = true;
            // 
            // pnlSettingAutoMode
            // 
            this.pnlSettingAutoMode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pnlSettingAutoMode.Controls.Add(this.lblAutoSeqEnable);
            this.pnlSettingAutoMode.Controls.Add(this.chkbAutoSeqEna);
            this.pnlSettingAutoMode.Controls.Add(this.checkedListBox);
            this.pnlSettingAutoMode.Controls.Add(this.bunifuSeparator1);
            this.pnlSettingAutoMode.Controls.Add(this.lblSettingAutoMode);
            this.pnlSettingAutoMode.Location = new System.Drawing.Point(36, 26);
            this.pnlSettingAutoMode.Name = "pnlSettingAutoMode";
            this.pnlSettingAutoMode.Size = new System.Drawing.Size(318, 202);
            this.pnlSettingAutoMode.TabIndex = 7;
            // 
            // lblAutoSeqEnable
            // 
            this.lblAutoSeqEnable.AutoSize = true;
            this.lblAutoSeqEnable.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAutoSeqEnable.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAutoSeqEnable.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAutoSeqEnable.Location = new System.Drawing.Point(193, 25);
            this.lblAutoSeqEnable.Name = "lblAutoSeqEnable";
            this.lblAutoSeqEnable.Size = new System.Drawing.Size(61, 17);
            this.lblAutoSeqEnable.TabIndex = 15;
            this.lblAutoSeqEnable.Text = "Enabled";
            // 
            // chkbAutoSeqEna
            // 
            this.chkbAutoSeqEna.BackColor = System.Drawing.Color.Transparent;
            this.chkbAutoSeqEna.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chkbAutoSeqEna.BackgroundImage")));
            this.chkbAutoSeqEna.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chkbAutoSeqEna.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkbAutoSeqEna.Location = new System.Drawing.Point(152, 24);
            this.chkbAutoSeqEna.Name = "chkbAutoSeqEna";
            this.chkbAutoSeqEna.OffColor = System.Drawing.Color.Gray;
            this.chkbAutoSeqEna.OnColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.chkbAutoSeqEna.Size = new System.Drawing.Size(35, 20);
            this.chkbAutoSeqEna.TabIndex = 14;
            this.chkbAutoSeqEna.Value = false;
            this.chkbAutoSeqEna.OnValueChange += new System.EventHandler(this.chkbAutoSeqEna_OnValueChange);
            // 
            // checkedListBox
            // 
            this.checkedListBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.checkedListBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.checkedListBox.CheckOnClick = true;
            this.checkedListBox.Enabled = false;
            this.checkedListBox.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBox.ForeColor = System.Drawing.Color.White;
            this.checkedListBox.FormattingEnabled = true;
            this.checkedListBox.Items.AddRange(new object[] {
            "Write",
            "Verify",
            "Read"});
            this.checkedListBox.Location = new System.Drawing.Point(146, 58);
            this.checkedListBox.Name = "checkedListBox";
            this.checkedListBox.Size = new System.Drawing.Size(73, 104);
            this.checkedListBox.TabIndex = 12;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(0, 2);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(10, 240);
            this.bunifuSeparator1.TabIndex = 3;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = true;
            // 
            // lblSettingAutoMode
            // 
            this.lblSettingAutoMode.AutoSize = true;
            this.lblSettingAutoMode.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSettingAutoMode.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSettingAutoMode.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSettingAutoMode.Location = new System.Drawing.Point(32, 26);
            this.lblSettingAutoMode.Name = "lblSettingAutoMode";
            this.lblSettingAutoMode.Size = new System.Drawing.Size(114, 17);
            this.lblSettingAutoMode.TabIndex = 8;
            this.lblSettingAutoMode.Text = "Auto Sequence :";
            // 
            // pnlSettingDbg
            // 
            this.pnlSettingDbg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pnlSettingDbg.Controls.Add(this.lblDbgModeEnabled);
            this.pnlSettingDbg.Controls.Add(this.chbDbgModeEnable);
            this.pnlSettingDbg.Controls.Add(this.bunifuSeparator2);
            this.pnlSettingDbg.Controls.Add(this.lblSettingDebug);
            this.pnlSettingDbg.Location = new System.Drawing.Point(36, 26);
            this.pnlSettingDbg.Name = "pnlSettingDbg";
            this.pnlSettingDbg.Size = new System.Drawing.Size(318, 202);
            this.pnlSettingDbg.TabIndex = 8;
            // 
            // lblDbgModeEnabled
            // 
            this.lblDbgModeEnabled.AutoSize = true;
            this.lblDbgModeEnabled.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDbgModeEnabled.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDbgModeEnabled.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDbgModeEnabled.Location = new System.Drawing.Point(187, 26);
            this.lblDbgModeEnabled.Name = "lblDbgModeEnabled";
            this.lblDbgModeEnabled.Size = new System.Drawing.Size(61, 17);
            this.lblDbgModeEnabled.TabIndex = 13;
            this.lblDbgModeEnabled.Text = "Enabled";
            // 
            // chbDbgModeEnable
            // 
            this.chbDbgModeEnable.BackColor = System.Drawing.Color.Transparent;
            this.chbDbgModeEnable.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chbDbgModeEnable.BackgroundImage")));
            this.chbDbgModeEnable.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chbDbgModeEnable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chbDbgModeEnable.Location = new System.Drawing.Point(146, 25);
            this.chbDbgModeEnable.Name = "chbDbgModeEnable";
            this.chbDbgModeEnable.OffColor = System.Drawing.Color.Gray;
            this.chbDbgModeEnable.OnColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.chbDbgModeEnable.Size = new System.Drawing.Size(35, 20);
            this.chbDbgModeEnable.TabIndex = 12;
            this.chbDbgModeEnable.Value = false;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(0, 2);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(10, 240);
            this.bunifuSeparator2.TabIndex = 3;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = true;
            // 
            // lblSettingDebug
            // 
            this.lblSettingDebug.AutoSize = true;
            this.lblSettingDebug.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSettingDebug.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSettingDebug.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSettingDebug.Location = new System.Drawing.Point(36, 26);
            this.lblSettingDebug.Name = "lblSettingDebug";
            this.lblSettingDebug.Size = new System.Drawing.Size(103, 17);
            this.lblSettingDebug.TabIndex = 8;
            this.lblSettingDebug.Text = "Debug mode :";
            // 
            // SettingForm
            // 
            this.AcceptButton = this.btnSettingOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(354, 280);
            this.Controls.Add(this.pnlSettingDbg);
            this.Controls.Add(this.pnlSettingAutoMode);
            this.Controls.Add(this.pnlSettingSerial);
            this.Controls.Add(this.pnlSettingLeft);
            this.Controls.Add(this.pnlSettingTop);
            this.Controls.Add(this.pnlSettingBottom);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SettingForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Setting";
            this.Load += new System.EventHandler(this.SettingForm_Load);
            this.pnlSettingTop.ResumeLayout(false);
            this.pnlSettingTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnSettingMinimize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSettingClose)).EndInit();
            this.pnlSettingLeft.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnSettingMenu)).EndInit();
            this.pnlSettingSerial.ResumeLayout(false);
            this.pnlSettingSerial.PerformLayout();
            this.pnlSettingBottom.ResumeLayout(false);
            this.pnlSettingAutoMode.ResumeLayout(false);
            this.pnlSettingAutoMode.PerformLayout();
            this.pnlSettingDbg.ResumeLayout(false);
            this.pnlSettingDbg.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlSettingTop;
        private System.Windows.Forms.Panel pnlSettingLeft;
        private System.Windows.Forms.Panel pnlSettingSerial;
        private Bunifu.Framework.UI.BunifuImageButton btnSettingMinimize;
        private Bunifu.Framework.UI.BunifuImageButton btnSettingClose;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        private System.Windows.Forms.Panel pnlSettingBottom;
        private Bunifu.Framework.UI.BunifuCustomLabel lblSettingTitle;
        private Bunifu.Framework.UI.BunifuCustomLabel lblSettingSerialPort;
        private Bunifu.Framework.UI.BunifuCustomLabel lblStopbit;
        private Bunifu.Framework.UI.BunifuCustomLabel lblParity;
        private Bunifu.Framework.UI.BunifuCustomLabel lblDatabit;
        private Bunifu.Framework.UI.BunifuCustomLabel lblBaudrate;
        private Bunifu.Framework.UI.BunifuCustomLabel lblComport;
        private Bunifu.Framework.UI.BunifuFlatButton btnRefreshPort;
        private System.Windows.Forms.ComboBox cmbSettingBaudrate;
        private System.Windows.Forms.ComboBox cmbSettingComPort;
        private System.Windows.Forms.Button btnSettingOK;
        private System.Windows.Forms.Button btnSettingCancel;
        private System.Windows.Forms.ComboBox cmbSettingStopBit;
        private System.Windows.Forms.ComboBox cmbSettingParity;
        private System.Windows.Forms.ComboBox cmbSettingDataBits;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuImageButton btnSettingMenu;
        private Bunifu.Framework.UI.BunifuFlatButton btnSerialPortSetting;
        private Bunifu.Framework.UI.BunifuFlatButton btnSettingDbg;
        private Bunifu.Framework.UI.BunifuFlatButton btnSettingAuto;
        private System.Windows.Forms.Panel pnlSettingAutoMode;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.Framework.UI.BunifuCustomLabel lblSettingAutoMode;
        private System.Windows.Forms.CheckedListBox checkedListBox;
        private System.Windows.Forms.Panel pnlSettingDbg;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private Bunifu.Framework.UI.BunifuCustomLabel lblSettingDebug;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator4;
        private Bunifu.Framework.UI.BunifuiOSSwitch chbDbgModeEnable;
        private Bunifu.Framework.UI.BunifuCustomLabel lblDbgModeEnabled;
        private Bunifu.Framework.UI.BunifuCustomLabel lblAutoSeqEnable;
        private Bunifu.Framework.UI.BunifuiOSSwitch chkbAutoSeqEna;
    }
}