﻿namespace SpecialRemoteGUI
{
    partial class AboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutForm));
            this.pnlAboutTop = new System.Windows.Forms.Panel();
            this.btnAboutMinimize = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnAboutClose = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.lblAboutTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pnlAboutCenter = new System.Windows.Forms.Panel();
            this.lblAbout = new System.Windows.Forms.Label();
            this.pictureBoxAboutIco = new System.Windows.Forms.PictureBox();
            this.rtbAbout = new System.Windows.Forms.RichTextBox();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.pnlAboutTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAboutMinimize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAboutClose)).BeginInit();
            this.pnlAboutCenter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAboutIco)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlAboutTop
            // 
            this.pnlAboutTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.pnlAboutTop.Controls.Add(this.lblAboutTitle);
            this.pnlAboutTop.Controls.Add(this.btnAboutMinimize);
            this.pnlAboutTop.Controls.Add(this.btnAboutClose);
            this.pnlAboutTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlAboutTop.Location = new System.Drawing.Point(0, 0);
            this.pnlAboutTop.Name = "pnlAboutTop";
            this.pnlAboutTop.Size = new System.Drawing.Size(406, 24);
            this.pnlAboutTop.TabIndex = 0;
            // 
            // btnAboutMinimize
            // 
            this.btnAboutMinimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnAboutMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAboutMinimize.Image = ((System.Drawing.Image)(resources.GetObject("btnAboutMinimize.Image")));
            this.btnAboutMinimize.ImageActive = null;
            this.btnAboutMinimize.Location = new System.Drawing.Point(357, 2);
            this.btnAboutMinimize.Name = "btnAboutMinimize";
            this.btnAboutMinimize.Size = new System.Drawing.Size(20, 20);
            this.btnAboutMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnAboutMinimize.TabIndex = 11;
            this.btnAboutMinimize.TabStop = false;
            this.btnAboutMinimize.Zoom = 10;
            this.btnAboutMinimize.Click += new System.EventHandler(this.btnAboutMinimize_Click);
            // 
            // btnAboutClose
            // 
            this.btnAboutClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnAboutClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAboutClose.Image = ((System.Drawing.Image)(resources.GetObject("btnAboutClose.Image")));
            this.btnAboutClose.ImageActive = null;
            this.btnAboutClose.Location = new System.Drawing.Point(383, 2);
            this.btnAboutClose.Name = "btnAboutClose";
            this.btnAboutClose.Size = new System.Drawing.Size(20, 20);
            this.btnAboutClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnAboutClose.TabIndex = 10;
            this.btnAboutClose.TabStop = false;
            this.btnAboutClose.Zoom = 10;
            this.btnAboutClose.Click += new System.EventHandler(this.btnAboutClose_Click);
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.pnlAboutTop;
            this.bunifuDragControl1.Vertical = true;
            // 
            // lblAboutTitle
            // 
            this.lblAboutTitle.AutoSize = true;
            this.lblAboutTitle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAboutTitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAboutTitle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAboutTitle.Location = new System.Drawing.Point(178, 4);
            this.lblAboutTitle.Name = "lblAboutTitle";
            this.lblAboutTitle.Size = new System.Drawing.Size(48, 17);
            this.lblAboutTitle.TabIndex = 1;
            this.lblAboutTitle.Text = "About";
            // 
            // pnlAboutCenter
            // 
            this.pnlAboutCenter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pnlAboutCenter.Controls.Add(this.bunifuSeparator1);
            this.pnlAboutCenter.Controls.Add(this.rtbAbout);
            this.pnlAboutCenter.Controls.Add(this.pictureBoxAboutIco);
            this.pnlAboutCenter.Controls.Add(this.lblAbout);
            this.pnlAboutCenter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAboutCenter.Location = new System.Drawing.Point(0, 24);
            this.pnlAboutCenter.Name = "pnlAboutCenter";
            this.pnlAboutCenter.Size = new System.Drawing.Size(406, 266);
            this.pnlAboutCenter.TabIndex = 1;
            // 
            // lblAbout
            // 
            this.lblAbout.AutoSize = true;
            this.lblAbout.ForeColor = System.Drawing.Color.White;
            this.lblAbout.Location = new System.Drawing.Point(86, 8);
            this.lblAbout.Name = "lblAbout";
            this.lblAbout.Size = new System.Drawing.Size(286, 78);
            this.lblAbout.TabIndex = 2;
            this.lblAbout.Text = resources.GetString("lblAbout.Text");
            // 
            // pictureBoxAboutIco
            // 
            this.pictureBoxAboutIco.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxAboutIco.Image")));
            this.pictureBoxAboutIco.Location = new System.Drawing.Point(24, 22);
            this.pictureBoxAboutIco.Name = "pictureBoxAboutIco";
            this.pictureBoxAboutIco.Size = new System.Drawing.Size(48, 48);
            this.pictureBoxAboutIco.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxAboutIco.TabIndex = 3;
            this.pictureBoxAboutIco.TabStop = false;
            // 
            // rtbAbout
            // 
            this.rtbAbout.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbAbout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.rtbAbout.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbAbout.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbAbout.ForeColor = System.Drawing.Color.White;
            this.rtbAbout.Location = new System.Drawing.Point(4, 96);
            this.rtbAbout.MaxLength = 0;
            this.rtbAbout.Name = "rtbAbout";
            this.rtbAbout.Size = new System.Drawing.Size(400, 158);
            this.rtbAbout.TabIndex = 17;
            this.rtbAbout.Text = "<Release History>\n\n[Date]:  14-Jan-2019    [Version]:  1.0\n[Modified point]:  - F" +
    "irst edit making\n[Author]:  S.Pairot";
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.bunifuSeparator1.LineThickness = 2;
            this.bunifuSeparator1.Location = new System.Drawing.Point(3, 252);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(401, 13);
            this.bunifuSeparator1.TabIndex = 18;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // AboutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 290);
            this.Controls.Add(this.pnlAboutCenter);
            this.Controls.Add(this.pnlAboutTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AboutForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "AboutForm";
            this.pnlAboutTop.ResumeLayout(false);
            this.pnlAboutTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAboutMinimize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAboutClose)).EndInit();
            this.pnlAboutCenter.ResumeLayout(false);
            this.pnlAboutCenter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAboutIco)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAboutTop;
        private Bunifu.Framework.UI.BunifuImageButton btnAboutMinimize;
        private Bunifu.Framework.UI.BunifuImageButton btnAboutClose;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuCustomLabel lblAboutTitle;
        private System.Windows.Forms.Panel pnlAboutCenter;
        private System.Windows.Forms.PictureBox pictureBoxAboutIco;
        private System.Windows.Forms.Label lblAbout;
        private System.Windows.Forms.RichTextBox rtbAbout;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
    }
}