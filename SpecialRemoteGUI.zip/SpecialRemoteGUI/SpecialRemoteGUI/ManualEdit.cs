﻿namespace SpecialRemoteGUI
{
    public class ManualEdit
    {
        public string Type          { get; set; }      // A/C Type FCU/CDU
        public string Total         { get; set; }      // Total
        public string E2Address     { get; set; }      // EEPROM address
        public string E2Data        { get; set; }      // EEPROM data
        public string E2BaseData    { get; set; }      // EEPROM base data 
    }
}
