﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SpecialRemoteGUI
{
    public partial class AddEditData : Form
    {
        public ManualEdit ManualEditInfo { get; set; }  // global object class

        public AddEditData()
        {
            InitializeComponent();
        }

        private void btnAddEditMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnAddEditClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddEditData_Load(object sender, EventArgs e)
        {
            // Init data
            if (ManualEditInfo != null)
            {                                                        // Exiting data?
                cmbType.Text = ManualEditInfo.Type;                  // Add Type to Textbox
                txtTotal.Text = ManualEditInfo.Total;                // Add Total to Textbox
                txtE2Address.Text = ManualEditInfo.E2Address;        // Add E2 Address to Textbox
                txtE2Data.Text = ManualEditInfo.E2Data;              // Add E2 Data to Textbox
                txtBaseE2Data.Text = ManualEditInfo.E2BaseData;      // Add Base E2 Data to Textbox
            }
            else
            {
                cmbType.Text = "FCU";                                // Display FCU
                txtTotal.Focus();                                    // Set cursor at ID box
            }
        }

        private void btnAddEditOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cmbType.Text) ||                  // Confirm all data was filled
                string.IsNullOrEmpty(txtTotal.Text) ||
                string.IsNullOrEmpty(txtE2Address.Text) ||
                string.IsNullOrEmpty(txtE2Data.Text) ||
                string.IsNullOrEmpty(txtBaseE2Data.Text))
            {
                if (DialogResult.OK == MessageBox.Show("Please enter data!!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation))
                {
                    this.DialogResult = DialogResult.None;           // If no fill data Keep form open
                }
            }
            else
            {
                ManualEditInfo.Type = cmbType.Text;
                ManualEditInfo.Total = txtTotal.Text;               // Copy data from text box to global class
                ManualEditInfo.E2Address = txtE2Address.Text;
                ManualEditInfo.E2Data = txtE2Data.Text;
                ManualEditInfo.E2BaseData = txtBaseE2Data.Text;
            }
        }

        private void btnAddEditCancel_Click(object sender, EventArgs e)
        {
            this.Close();  // form close
        }

        // Check string input is hex data
        public bool IsHexValue(string strInput)
        {
            //create Regular Expression Match pattern object
            Regex myRegex = new Regex("^[a-fA-F0-9]+$");
            //boolean variable to hold the status
            bool isValid = false;
            if (string.IsNullOrEmpty(strInput))
            {
                isValid = false;
            }
            else
            {
                isValid = myRegex.IsMatch(strInput);
            }
            //return the results
            return isValid;
        }

        private void txtTotal_Leave(object sender, EventArgs e)
        {
            if (IsHexValue(txtTotal.Text))                     // is hex value and no empty
            {
                txtTotal.Text = txtTotal.Text.PadLeft(2, '0'); // Add prefix 0 if only 1 digit
                txtTotal.Text = txtTotal.Text.ToUpper();       // Upper case convert

            }
            else
            {                                                  // Incorrect data format
                txtTotal.Text = "";                            // Set empty
            }
        }

        private void txtE2Address_Leave(object sender, EventArgs e)
        {
            if (IsHexValue(txtE2Address.Text))                         // is hex value and no empty
            {
                txtE2Address.Text = txtE2Address.Text.PadLeft(2, '0'); // Add prefix 0 if only 1 digit
                txtE2Address.Text = txtE2Address.Text.ToUpper();       // Upper case convert

            }
            else
            {                                                          // Incorrect data format
                txtE2Address.Text = "";                                // Set empty
            }
        }

        private void txtE2Data_Leave(object sender, EventArgs e)
        {
            if (IsHexValue(txtE2Data.Text))                      // is hex value and no empty
            {
                txtE2Data.Text = txtE2Data.Text.PadLeft(2, '0'); // Add prefix 0 if only 1 digit
                txtE2Data.Text = txtE2Data.Text.ToUpper();       // Upper case convert

            }
            else
            {                                                    // Incorrect data format
                txtE2Data.Text = "";                             // Set empty
            }
        }

        private void txtBaseE2Data_Leave(object sender, EventArgs e)
        {
            if (IsHexValue(txtBaseE2Data.Text))                          // is hex value and no empty
            {
                txtBaseE2Data.Text = txtBaseE2Data.Text.PadLeft(2, '0'); // Add prefix 0 if only 1 digit
                txtBaseE2Data.Text = txtBaseE2Data.Text.ToUpper();       // Upper case convert

            }
            else
            {                                                            // Incorrect data format
                txtBaseE2Data.Text = "";                                 // Set empty
            }
        }
    }
}
