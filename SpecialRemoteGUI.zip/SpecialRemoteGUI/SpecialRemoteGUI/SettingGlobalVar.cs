﻿using System;
using System.IO.Ports;  /*Serial port*/

namespace SpecialRemoteGUI
{
    public class SettingData
    {
        public string ComPortName          { get; set; }
        public Int32 Baudrate              { get; set; }
        public Int16 DataBits              { get; set; }
        public Parity Parity               { get; set; }
        public StopBits StopBits           { get; set; }
        public bool debugModeEnable        { get; set; }
        public bool AutoSeqEnable          { get; set; }
        public bool Write                  { get; set; }
        public bool Verify                 { get; set; }
        public bool Read                   { get; set; }
    }

    /*Back up data class*/
    public class BackupData
    {
        public static string ComPortName   { get; set; }  // static var <ComPortName
        public static Int32 Baudrate       { get; set; }  // static var <Baudrate
        public static Int16 DataBits       { get; set; }  // static var <DataBits
        public static Parity Parity        { get; set; }  // static var <Parity
        public static StopBits StopBits    { get; set; }  // static var <StopBits
        public static bool debugModeEnable { get; set; }  // static var <Debug enabled
        public static bool AutoSeqEnable   { get; set; }  // static var <Auto sequence enabled
        public static bool Write           { get; set; }  // static var <write data
        public static bool Verify          { get; set; }  // static var <verify data
        public static bool Read            { get; set; }  // static var <read data
    }
}
