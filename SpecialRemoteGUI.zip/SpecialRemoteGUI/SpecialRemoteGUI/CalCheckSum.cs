﻿namespace SpecialRemoteGUI
{
    class CalCheckSum
    {
        /*
        Function : MAIN_GetSumData
        Detail   : Check sum data
        Input    : in_dat
        Output   : sum of data (if OK must be 0)
        History  : 2018-11-15 First written by S.Pairot
        */
        public byte SUM_GetSumData(byte[] in_dat)
        {                                              //
            byte L_sumdat = 0;                         //
            foreach (byte data in in_dat)              // get one byte from array
            {                                          //
                L_sumdat -= data;                      // calculate check sum
            }                                          //
            return (L_sumdat);                         // return result
        }                                              //
    }
}
