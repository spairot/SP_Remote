﻿namespace SpecialRemoteGUI
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlTopMenu = new System.Windows.Forms.Panel();
            this.lblProgramTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnMinimize = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnClose = new Bunifu.Framework.UI.BunifuImageButton();
            this.pnlLeftMenu = new System.Windows.Forms.Panel();
            this.picIcon = new System.Windows.Forms.PictureBox();
            this.pnlLeftMenuCursor = new System.Windows.Forms.Panel();
            this.btnSetting = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.btnControl = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.pnlDashBoard = new System.Windows.Forms.Panel();
            this.pnlControl = new System.Windows.Forms.Panel();
            this.txtTaskLog = new System.Windows.Forms.RichTextBox();
            this.btnRead = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnVerify = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnWrite = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnStart = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnConnect = new Bunifu.Framework.UI.BunifuTileButton();
            this.lblStatus = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblAutoSeq = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuSeparator5 = new Bunifu.Framework.UI.BunifuSeparator();
            this.btnDisconnect = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnDelete = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnEdit = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnAdd = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnSave = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnOpen = new Bunifu.Framework.UI.BunifuTileButton();
            this.btnNew = new Bunifu.Framework.UI.BunifuTileButton();
            this.lblManualEdit = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.sliManualEdit = new Bunifu.Framework.UI.BunifuiOSSwitch();
            this.lblLoadDataFile = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.sliLoadDataFile = new Bunifu.Framework.UI.BunifuiOSSwitch();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.txtInputBox = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.pnlWindow = new System.Windows.Forms.Panel();
            this.pnlModeDebug = new System.Windows.Forms.Panel();
            this.rtbDebug = new System.Windows.Forms.RichTextBox();
            this.pnlModeRead = new System.Windows.Forms.Panel();
            this.listView = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pnlModeWrite = new System.Windows.Forms.Panel();
            this.dataGridViewCode = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.cboFile = new System.Windows.Forms.ComboBox();
            this.lblDebug = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkboxDebug = new Bunifu.Framework.UI.BunifuCheckbox();
            this.lblReadMode = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkboxRead = new Bunifu.Framework.UI.BunifuCheckbox();
            this.lblWrite = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblDisplayMode = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkboxWrite = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pnlTopMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            this.pnlLeftMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picIcon)).BeginInit();
            this.pnlDashBoard.SuspendLayout();
            this.pnlControl.SuspendLayout();
            this.pnlWindow.SuspendLayout();
            this.pnlModeDebug.SuspendLayout();
            this.pnlModeRead.SuspendLayout();
            this.pnlModeWrite.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCode)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTopMenu
            // 
            this.pnlTopMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.pnlTopMenu.Controls.Add(this.lblProgramTitle);
            this.pnlTopMenu.Controls.Add(this.btnMinimize);
            this.pnlTopMenu.Controls.Add(this.btnClose);
            this.pnlTopMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopMenu.Location = new System.Drawing.Point(0, 0);
            this.pnlTopMenu.Name = "pnlTopMenu";
            this.pnlTopMenu.Size = new System.Drawing.Size(647, 28);
            this.pnlTopMenu.TabIndex = 0;
            // 
            // lblProgramTitle
            // 
            this.lblProgramTitle.AutoSize = true;
            this.lblProgramTitle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgramTitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblProgramTitle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblProgramTitle.Location = new System.Drawing.Point(261, 6);
            this.lblProgramTitle.Name = "lblProgramTitle";
            this.lblProgramTitle.Size = new System.Drawing.Size(155, 17);
            this.lblProgramTitle.TabIndex = 3;
            this.lblProgramTitle.Text = "Special Remote UI V1.0";
            // 
            // btnMinimize
            // 
            this.btnMinimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimize.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimize.Image")));
            this.btnMinimize.ImageActive = null;
            this.btnMinimize.Location = new System.Drawing.Point(589, 4);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(20, 20);
            this.btnMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnMinimize.TabIndex = 2;
            this.btnMinimize.TabStop = false;
            this.btnMinimize.Zoom = 10;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.ImageActive = null;
            this.btnClose.Location = new System.Drawing.Point(615, 4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(20, 20);
            this.btnClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnClose.TabIndex = 1;
            this.btnClose.TabStop = false;
            this.btnClose.Zoom = 10;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pnlLeftMenu
            // 
            this.pnlLeftMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pnlLeftMenu.Controls.Add(this.picIcon);
            this.pnlLeftMenu.Controls.Add(this.pnlLeftMenuCursor);
            this.pnlLeftMenu.Controls.Add(this.btnSetting);
            this.pnlLeftMenu.Controls.Add(this.btnHelp);
            this.pnlLeftMenu.Controls.Add(this.btnControl);
            this.pnlLeftMenu.Controls.Add(this.btnDashboard);
            this.pnlLeftMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLeftMenu.Location = new System.Drawing.Point(0, 28);
            this.pnlLeftMenu.Name = "pnlLeftMenu";
            this.pnlLeftMenu.Size = new System.Drawing.Size(123, 464);
            this.pnlLeftMenu.TabIndex = 1;
            // 
            // picIcon
            // 
            this.picIcon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.picIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picIcon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picIcon.Image = ((System.Drawing.Image)(resources.GetObject("picIcon.Image")));
            this.picIcon.Location = new System.Drawing.Point(3, 5);
            this.picIcon.Name = "picIcon";
            this.picIcon.Size = new System.Drawing.Size(117, 52);
            this.picIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picIcon.TabIndex = 5;
            this.picIcon.TabStop = false;
            this.picIcon.Click += new System.EventHandler(this.picIcon_Click);
            // 
            // pnlLeftMenuCursor
            // 
            this.pnlLeftMenuCursor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.pnlLeftMenuCursor.Location = new System.Drawing.Point(0, 64);
            this.pnlLeftMenuCursor.Name = "pnlLeftMenuCursor";
            this.pnlLeftMenuCursor.Size = new System.Drawing.Size(5, 79);
            this.pnlLeftMenuCursor.TabIndex = 1;
            // 
            // btnSetting
            // 
            this.btnSetting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSetting.FlatAppearance.BorderSize = 0;
            this.btnSetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSetting.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetting.ForeColor = System.Drawing.Color.White;
            this.btnSetting.Image = ((System.Drawing.Image)(resources.GetObject("btnSetting.Image")));
            this.btnSetting.Location = new System.Drawing.Point(4, 234);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(120, 79);
            this.btnSetting.TabIndex = 3;
            this.btnSetting.Text = "Setting";
            this.btnSetting.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSetting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnHelp
            // 
            this.btnHelp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHelp.FlatAppearance.BorderSize = 0;
            this.btnHelp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHelp.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHelp.ForeColor = System.Drawing.Color.White;
            this.btnHelp.Image = ((System.Drawing.Image)(resources.GetObject("btnHelp.Image")));
            this.btnHelp.Location = new System.Drawing.Point(4, 319);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(120, 79);
            this.btnHelp.TabIndex = 4;
            this.btnHelp.Text = "Help";
            this.btnHelp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnHelp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // btnControl
            // 
            this.btnControl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnControl.FlatAppearance.BorderSize = 0;
            this.btnControl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnControl.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnControl.ForeColor = System.Drawing.Color.White;
            this.btnControl.Image = ((System.Drawing.Image)(resources.GetObject("btnControl.Image")));
            this.btnControl.Location = new System.Drawing.Point(4, 149);
            this.btnControl.Name = "btnControl";
            this.btnControl.Size = new System.Drawing.Size(120, 79);
            this.btnControl.TabIndex = 2;
            this.btnControl.Text = "Control";
            this.btnControl.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnControl.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnControl.UseVisualStyleBackColor = true;
            this.btnControl.Click += new System.EventHandler(this.btnControl_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.ForeColor = System.Drawing.Color.White;
            this.btnDashboard.Image = ((System.Drawing.Image)(resources.GetObject("btnDashboard.Image")));
            this.btnDashboard.Location = new System.Drawing.Point(4, 64);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(120, 79);
            this.btnDashboard.TabIndex = 1;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDashboard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDashboard.UseVisualStyleBackColor = true;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // pnlDashBoard
            // 
            this.pnlDashBoard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pnlDashBoard.Controls.Add(this.pnlControl);
            this.pnlDashBoard.Controls.Add(this.btnDelete);
            this.pnlDashBoard.Controls.Add(this.btnEdit);
            this.pnlDashBoard.Controls.Add(this.btnAdd);
            this.pnlDashBoard.Controls.Add(this.btnSave);
            this.pnlDashBoard.Controls.Add(this.btnOpen);
            this.pnlDashBoard.Controls.Add(this.btnNew);
            this.pnlDashBoard.Controls.Add(this.lblManualEdit);
            this.pnlDashBoard.Controls.Add(this.sliManualEdit);
            this.pnlDashBoard.Controls.Add(this.lblLoadDataFile);
            this.pnlDashBoard.Controls.Add(this.sliLoadDataFile);
            this.pnlDashBoard.Controls.Add(this.bunifuSeparator2);
            this.pnlDashBoard.Controls.Add(this.bunifuSeparator1);
            this.pnlDashBoard.Location = new System.Drawing.Point(123, 28);
            this.pnlDashBoard.Name = "pnlDashBoard";
            this.pnlDashBoard.Size = new System.Drawing.Size(524, 180);
            this.pnlDashBoard.TabIndex = 2;
            // 
            // pnlControl
            // 
            this.pnlControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pnlControl.Controls.Add(this.txtTaskLog);
            this.pnlControl.Controls.Add(this.btnRead);
            this.pnlControl.Controls.Add(this.btnVerify);
            this.pnlControl.Controls.Add(this.btnWrite);
            this.pnlControl.Controls.Add(this.btnStart);
            this.pnlControl.Controls.Add(this.btnConnect);
            this.pnlControl.Controls.Add(this.lblStatus);
            this.pnlControl.Controls.Add(this.lblAutoSeq);
            this.pnlControl.Controls.Add(this.bunifuSeparator5);
            this.pnlControl.Controls.Add(this.btnDisconnect);
            this.pnlControl.Location = new System.Drawing.Point(1, 0);
            this.pnlControl.Name = "pnlControl";
            this.pnlControl.Size = new System.Drawing.Size(524, 180);
            this.pnlControl.TabIndex = 13;
            // 
            // txtTaskLog
            // 
            this.txtTaskLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.txtTaskLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTaskLog.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTaskLog.ForeColor = System.Drawing.Color.White;
            this.txtTaskLog.Location = new System.Drawing.Point(4, 25);
            this.txtTaskLog.MaxLength = 0;
            this.txtTaskLog.Name = "txtTaskLog";
            this.txtTaskLog.Size = new System.Drawing.Size(168, 145);
            this.txtTaskLog.TabIndex = 12;
            this.txtTaskLog.Text = "";
            // 
            // btnRead
            // 
            this.btnRead.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnRead.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnRead.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnRead.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(70)))), ((int)(((byte)(0)))));
            this.btnRead.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRead.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRead.ForeColor = System.Drawing.Color.White;
            this.btnRead.Image = ((System.Drawing.Image)(resources.GetObject("btnRead.Image")));
            this.btnRead.ImagePosition = 10;
            this.btnRead.ImageZoom = 55;
            this.btnRead.LabelPosition = 21;
            this.btnRead.LabelText = "Read";
            this.btnRead.Location = new System.Drawing.Point(339, 90);
            this.btnRead.Margin = new System.Windows.Forms.Padding(6);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(75, 80);
            this.btnRead.TabIndex = 10;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // btnVerify
            // 
            this.btnVerify.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnVerify.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnVerify.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnVerify.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(70)))), ((int)(((byte)(0)))));
            this.btnVerify.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerify.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerify.ForeColor = System.Drawing.Color.White;
            this.btnVerify.Image = ((System.Drawing.Image)(resources.GetObject("btnVerify.Image")));
            this.btnVerify.ImagePosition = 14;
            this.btnVerify.ImageZoom = 45;
            this.btnVerify.LabelPosition = 21;
            this.btnVerify.LabelText = "Verify";
            this.btnVerify.Location = new System.Drawing.Point(258, 90);
            this.btnVerify.Margin = new System.Windows.Forms.Padding(6);
            this.btnVerify.Name = "btnVerify";
            this.btnVerify.Size = new System.Drawing.Size(75, 80);
            this.btnVerify.TabIndex = 9;
            this.btnVerify.Click += new System.EventHandler(this.btnVerify_Click);
            // 
            // btnWrite
            // 
            this.btnWrite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnWrite.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnWrite.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnWrite.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(70)))), ((int)(((byte)(0)))));
            this.btnWrite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWrite.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWrite.ForeColor = System.Drawing.Color.White;
            this.btnWrite.Image = ((System.Drawing.Image)(resources.GetObject("btnWrite.Image")));
            this.btnWrite.ImagePosition = 10;
            this.btnWrite.ImageZoom = 55;
            this.btnWrite.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnWrite.LabelPosition = 21;
            this.btnWrite.LabelText = "Write";
            this.btnWrite.Location = new System.Drawing.Point(177, 90);
            this.btnWrite.Margin = new System.Windows.Forms.Padding(6);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(75, 80);
            this.btnWrite.TabIndex = 8;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnStart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnStart.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnStart.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(70)))), ((int)(((byte)(0)))));
            this.btnStart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStart.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.ForeColor = System.Drawing.Color.White;
            this.btnStart.Image = ((System.Drawing.Image)(resources.GetObject("btnStart.Image")));
            this.btnStart.ImagePosition = 11;
            this.btnStart.ImageZoom = 30;
            this.btnStart.LabelPosition = 21;
            this.btnStart.LabelText = "Auto program";
            this.btnStart.Location = new System.Drawing.Point(258, 5);
            this.btnStart.Margin = new System.Windows.Forms.Padding(6);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(156, 80);
            this.btnStart.TabIndex = 7;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnConnect.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnConnect.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnConnect.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(70)))), ((int)(((byte)(0)))));
            this.btnConnect.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConnect.Enabled = false;
            this.btnConnect.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnect.ForeColor = System.Drawing.Color.White;
            this.btnConnect.Image = ((System.Drawing.Image)(resources.GetObject("btnConnect.Image")));
            this.btnConnect.ImagePosition = 10;
            this.btnConnect.ImageZoom = 60;
            this.btnConnect.LabelPosition = 21;
            this.btnConnect.LabelText = "Connect";
            this.btnConnect.Location = new System.Drawing.Point(177, 5);
            this.btnConnect.Margin = new System.Windows.Forms.Padding(6);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 80);
            this.btnConnect.TabIndex = 5;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblStatus.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblStatus.Location = new System.Drawing.Point(7, 5);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(56, 16);
            this.lblStatus.TabIndex = 3;
            this.lblStatus.Text = "Task log";
            // 
            // lblAutoSeq
            // 
            this.lblAutoSeq.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAutoSeq.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAutoSeq.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAutoSeq.Location = new System.Drawing.Point(422, 8);
            this.lblAutoSeq.Name = "lblAutoSeq";
            this.lblAutoSeq.Size = new System.Drawing.Size(91, 162);
            this.lblAutoSeq.TabIndex = 1;
            this.lblAutoSeq.Text = "Auto";
            // 
            // bunifuSeparator5
            // 
            this.bunifuSeparator5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.bunifuSeparator5.LineThickness = 1;
            this.bunifuSeparator5.Location = new System.Drawing.Point(1, 170);
            this.bunifuSeparator5.Name = "bunifuSeparator5";
            this.bunifuSeparator5.Size = new System.Drawing.Size(522, 10);
            this.bunifuSeparator5.TabIndex = 1;
            this.bunifuSeparator5.Transparency = 255;
            this.bunifuSeparator5.Vertical = false;
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnDisconnect.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnDisconnect.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnDisconnect.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(70)))), ((int)(((byte)(0)))));
            this.btnDisconnect.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDisconnect.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisconnect.ForeColor = System.Drawing.Color.White;
            this.btnDisconnect.Image = ((System.Drawing.Image)(resources.GetObject("btnDisconnect.Image")));
            this.btnDisconnect.ImagePosition = 9;
            this.btnDisconnect.ImageZoom = 60;
            this.btnDisconnect.LabelPosition = 20;
            this.btnDisconnect.LabelText = "Disconnect";
            this.btnDisconnect.Location = new System.Drawing.Point(178, 5);
            this.btnDisconnect.Margin = new System.Windows.Forms.Padding(6);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(75, 80);
            this.btnDisconnect.TabIndex = 6;
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnDelete.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnDelete.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnDelete.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(70)))), ((int)(((byte)(0)))));
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImagePosition = 10;
            this.btnDelete.ImageZoom = 55;
            this.btnDelete.LabelPosition = 21;
            this.btnDelete.LabelText = "Delete";
            this.btnDelete.Location = new System.Drawing.Point(340, 90);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 80);
            this.btnDelete.TabIndex = 10;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnEdit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnEdit.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnEdit.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(70)))), ((int)(((byte)(0)))));
            this.btnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.ForeColor = System.Drawing.Color.White;
            this.btnEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit.Image")));
            this.btnEdit.ImagePosition = 10;
            this.btnEdit.ImageZoom = 55;
            this.btnEdit.LabelPosition = 21;
            this.btnEdit.LabelText = "Edit";
            this.btnEdit.Location = new System.Drawing.Point(259, 90);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(6);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 80);
            this.btnEdit.TabIndex = 9;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnAdd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnAdd.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnAdd.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(70)))), ((int)(((byte)(0)))));
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImagePosition = 10;
            this.btnAdd.ImageZoom = 55;
            this.btnAdd.LabelPosition = 21;
            this.btnAdd.LabelText = "Add";
            this.btnAdd.Location = new System.Drawing.Point(178, 90);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(6);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 80);
            this.btnAdd.TabIndex = 8;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnSave.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnSave.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnSave.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(70)))), ((int)(((byte)(0)))));
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImagePosition = 11;
            this.btnSave.ImageZoom = 50;
            this.btnSave.LabelPosition = 21;
            this.btnSave.LabelText = "Save";
            this.btnSave.Location = new System.Drawing.Point(340, 5);
            this.btnSave.Margin = new System.Windows.Forms.Padding(6);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 80);
            this.btnSave.TabIndex = 7;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnOpen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnOpen.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnOpen.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(70)))), ((int)(((byte)(0)))));
            this.btnOpen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOpen.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpen.ForeColor = System.Drawing.Color.White;
            this.btnOpen.Image = ((System.Drawing.Image)(resources.GetObject("btnOpen.Image")));
            this.btnOpen.ImagePosition = 10;
            this.btnOpen.ImageZoom = 55;
            this.btnOpen.LabelPosition = 21;
            this.btnOpen.LabelText = "Open";
            this.btnOpen.Location = new System.Drawing.Point(259, 5);
            this.btnOpen.Margin = new System.Windows.Forms.Padding(6);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(75, 80);
            this.btnOpen.TabIndex = 6;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnNew.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnNew.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.btnNew.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(70)))), ((int)(((byte)(0)))));
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.ForeColor = System.Drawing.Color.White;
            this.btnNew.Image = ((System.Drawing.Image)(resources.GetObject("btnNew.Image")));
            this.btnNew.ImagePosition = 10;
            this.btnNew.ImageZoom = 55;
            this.btnNew.LabelPosition = 21;
            this.btnNew.LabelText = "New";
            this.btnNew.Location = new System.Drawing.Point(178, 5);
            this.btnNew.Margin = new System.Windows.Forms.Padding(6);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(75, 80);
            this.btnNew.TabIndex = 5;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // lblManualEdit
            // 
            this.lblManualEdit.AutoSize = true;
            this.lblManualEdit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManualEdit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblManualEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblManualEdit.Location = new System.Drawing.Point(20, 123);
            this.lblManualEdit.Name = "lblManualEdit";
            this.lblManualEdit.Size = new System.Drawing.Size(79, 17);
            this.lblManualEdit.TabIndex = 3;
            this.lblManualEdit.Text = "Manual edit";
            // 
            // sliManualEdit
            // 
            this.sliManualEdit.BackColor = System.Drawing.Color.Transparent;
            this.sliManualEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sliManualEdit.BackgroundImage")));
            this.sliManualEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sliManualEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sliManualEdit.Location = new System.Drawing.Point(113, 120);
            this.sliManualEdit.Name = "sliManualEdit";
            this.sliManualEdit.OffColor = System.Drawing.Color.Gray;
            this.sliManualEdit.OnColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.sliManualEdit.Size = new System.Drawing.Size(35, 20);
            this.sliManualEdit.TabIndex = 4;
            this.sliManualEdit.Value = false;
            this.sliManualEdit.Click += new System.EventHandler(this.sliManualEdit_Click);
            // 
            // lblLoadDataFile
            // 
            this.lblLoadDataFile.AutoSize = true;
            this.lblLoadDataFile.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoadDataFile.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLoadDataFile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblLoadDataFile.Location = new System.Drawing.Point(20, 35);
            this.lblLoadDataFile.Name = "lblLoadDataFile";
            this.lblLoadDataFile.Size = new System.Drawing.Size(91, 17);
            this.lblLoadDataFile.TabIndex = 1;
            this.lblLoadDataFile.Text = "Load data file";
            // 
            // sliLoadDataFile
            // 
            this.sliLoadDataFile.BackColor = System.Drawing.Color.Transparent;
            this.sliLoadDataFile.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sliLoadDataFile.BackgroundImage")));
            this.sliLoadDataFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sliLoadDataFile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sliLoadDataFile.Location = new System.Drawing.Point(113, 35);
            this.sliLoadDataFile.Name = "sliLoadDataFile";
            this.sliLoadDataFile.OffColor = System.Drawing.Color.Gray;
            this.sliLoadDataFile.OnColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.sliLoadDataFile.Size = new System.Drawing.Size(35, 20);
            this.sliLoadDataFile.TabIndex = 2;
            this.sliLoadDataFile.Value = true;
            this.sliLoadDataFile.Click += new System.EventHandler(this.sliLoadDataFile_Click);
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(-5, 0);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(10, 419);
            this.bunifuSeparator2.TabIndex = 0;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = true;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(1, 170);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(522, 10);
            this.bunifuSeparator1.TabIndex = 1;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // txtInputBox
            // 
            this.txtInputBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.txtInputBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtInputBox.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtInputBox.ForeColor = System.Drawing.Color.White;
            this.txtInputBox.HintForeColor = System.Drawing.Color.White;
            this.txtInputBox.HintText = "Typing...";
            this.txtInputBox.isPassword = false;
            this.txtInputBox.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(102)))), ((int)(((byte)(0)))));
            this.txtInputBox.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.txtInputBox.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(102)))), ((int)(((byte)(0)))));
            this.txtInputBox.LineThickness = 2;
            this.txtInputBox.Location = new System.Drawing.Point(412, 218);
            this.txtInputBox.Margin = new System.Windows.Forms.Padding(4);
            this.txtInputBox.Name = "txtInputBox";
            this.txtInputBox.Size = new System.Drawing.Size(98, 28);
            this.txtInputBox.TabIndex = 11;
            this.txtInputBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtInputBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtInputBox_KeyDown);
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.pnlTopMenu;
            this.bunifuDragControl1.Vertical = true;
            // 
            // pnlWindow
            // 
            this.pnlWindow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pnlWindow.Controls.Add(this.pnlModeDebug);
            this.pnlWindow.Controls.Add(this.pnlModeRead);
            this.pnlWindow.Controls.Add(this.pnlModeWrite);
            this.pnlWindow.Controls.Add(this.cboFile);
            this.pnlWindow.Controls.Add(this.lblDebug);
            this.pnlWindow.Controls.Add(this.chkboxDebug);
            this.pnlWindow.Controls.Add(this.lblReadMode);
            this.pnlWindow.Controls.Add(this.chkboxRead);
            this.pnlWindow.Controls.Add(this.lblWrite);
            this.pnlWindow.Controls.Add(this.lblDisplayMode);
            this.pnlWindow.Controls.Add(this.chkboxWrite);
            this.pnlWindow.Controls.Add(this.bunifuSeparator3);
            this.pnlWindow.Location = new System.Drawing.Point(123, 208);
            this.pnlWindow.Name = "pnlWindow";
            this.pnlWindow.Size = new System.Drawing.Size(524, 284);
            this.pnlWindow.TabIndex = 3;
            // 
            // pnlModeDebug
            // 
            this.pnlModeDebug.Controls.Add(this.rtbDebug);
            this.pnlModeDebug.Controls.Add(this.txtInputBox);
            this.pnlModeDebug.Location = new System.Drawing.Point(3, 31);
            this.pnlModeDebug.Name = "pnlModeDebug";
            this.pnlModeDebug.Size = new System.Drawing.Size(518, 250);
            this.pnlModeDebug.TabIndex = 15;
            // 
            // rtbDebug
            // 
            this.rtbDebug.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbDebug.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.rtbDebug.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbDebug.ForeColor = System.Drawing.Color.White;
            this.rtbDebug.Location = new System.Drawing.Point(3, 3);
            this.rtbDebug.MaxLength = 0;
            this.rtbDebug.Name = "rtbDebug";
            this.rtbDebug.Size = new System.Drawing.Size(514, 217);
            this.rtbDebug.TabIndex = 16;
            this.rtbDebug.Text = "";
            // 
            // pnlModeRead
            // 
            this.pnlModeRead.Controls.Add(this.listView);
            this.pnlModeRead.Location = new System.Drawing.Point(3, 31);
            this.pnlModeRead.Name = "pnlModeRead";
            this.pnlModeRead.Size = new System.Drawing.Size(518, 250);
            this.pnlModeRead.TabIndex = 16;
            // 
            // listView
            // 
            this.listView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.listView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listView.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView.ForeColor = System.Drawing.Color.White;
            this.listView.GridLines = true;
            this.listView.HideSelection = false;
            this.listView.Location = new System.Drawing.Point(4, 3);
            this.listView.MultiSelect = false;
            this.listView.Name = "listView";
            this.listView.Size = new System.Drawing.Size(511, 244);
            this.listView.TabIndex = 1;
            this.listView.UseCompatibleStateImageBehavior = false;
            this.listView.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Total";
            this.columnHeader1.Width = 50;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Address";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "New data";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 80;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Base data";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 80;
            // 
            // pnlModeWrite
            // 
            this.pnlModeWrite.Controls.Add(this.dataGridViewCode);
            this.pnlModeWrite.Location = new System.Drawing.Point(3, 31);
            this.pnlModeWrite.Name = "pnlModeWrite";
            this.pnlModeWrite.Size = new System.Drawing.Size(518, 250);
            this.pnlModeWrite.TabIndex = 13;
            // 
            // dataGridViewCode
            // 
            this.dataGridViewCode.AllowDrop = true;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridViewCode.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewCode.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewCode.BackgroundColor = System.Drawing.Color.Black;
            this.dataGridViewCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewCode.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCode.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewCode.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCode.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridViewCode.DoubleBuffered = true;
            this.dataGridViewCode.EnableHeadersVisualStyles = false;
            this.dataGridViewCode.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.dataGridViewCode.HeaderBgColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.dataGridViewCode.HeaderForeColor = System.Drawing.Color.White;
            this.dataGridViewCode.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewCode.Name = "dataGridViewCode";
            this.dataGridViewCode.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridViewCode.Size = new System.Drawing.Size(512, 243);
            this.dataGridViewCode.TabIndex = 4;
            this.dataGridViewCode.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewCode_CellClick);
            this.dataGridViewCode.DragDrop += new System.Windows.Forms.DragEventHandler(this.dataGridViewCode_DragDrop);
            this.dataGridViewCode.DragEnter += new System.Windows.Forms.DragEventHandler(this.dataGridViewCode_DragEnter);
            // 
            // cboFile
            // 
            this.cboFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.cboFile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cboFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboFile.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboFile.ForeColor = System.Drawing.SystemColors.Window;
            this.cboFile.FormattingEnabled = true;
            this.cboFile.Location = new System.Drawing.Point(357, 3);
            this.cboFile.Name = "cboFile";
            this.cboFile.Size = new System.Drawing.Size(164, 24);
            this.cboFile.TabIndex = 3;
            this.cboFile.SelectedIndexChanged += new System.EventHandler(this.cboFile_SelectedIndexChanged);
            // 
            // lblDebug
            // 
            this.lblDebug.AutoSize = true;
            this.lblDebug.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDebug.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDebug.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDebug.Location = new System.Drawing.Point(263, 7);
            this.lblDebug.Name = "lblDebug";
            this.lblDebug.Size = new System.Drawing.Size(48, 17);
            this.lblDebug.TabIndex = 12;
            this.lblDebug.Text = "Debug";
            // 
            // chkboxDebug
            // 
            this.chkboxDebug.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.chkboxDebug.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.chkboxDebug.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.chkboxDebug.Checked = false;
            this.chkboxDebug.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.chkboxDebug.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkboxDebug.ForeColor = System.Drawing.Color.White;
            this.chkboxDebug.Location = new System.Drawing.Point(315, 6);
            this.chkboxDebug.Name = "chkboxDebug";
            this.chkboxDebug.Size = new System.Drawing.Size(20, 20);
            this.chkboxDebug.TabIndex = 2;
            this.chkboxDebug.Click += new System.EventHandler(this.chkboxDebug_Click);
            // 
            // lblReadMode
            // 
            this.lblReadMode.AutoSize = true;
            this.lblReadMode.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReadMode.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblReadMode.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblReadMode.Location = new System.Drawing.Point(187, 7);
            this.lblReadMode.Name = "lblReadMode";
            this.lblReadMode.Size = new System.Drawing.Size(39, 17);
            this.lblReadMode.TabIndex = 10;
            this.lblReadMode.Text = "Read";
            // 
            // chkboxRead
            // 
            this.chkboxRead.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.chkboxRead.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.chkboxRead.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.chkboxRead.Checked = false;
            this.chkboxRead.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.chkboxRead.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkboxRead.ForeColor = System.Drawing.Color.White;
            this.chkboxRead.Location = new System.Drawing.Point(230, 6);
            this.chkboxRead.Name = "chkboxRead";
            this.chkboxRead.Size = new System.Drawing.Size(20, 20);
            this.chkboxRead.TabIndex = 1;
            this.chkboxRead.Click += new System.EventHandler(this.chkboxRead_Click);
            // 
            // lblWrite
            // 
            this.lblWrite.AutoSize = true;
            this.lblWrite.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWrite.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblWrite.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblWrite.Location = new System.Drawing.Point(108, 6);
            this.lblWrite.Name = "lblWrite";
            this.lblWrite.Size = new System.Drawing.Size(41, 17);
            this.lblWrite.TabIndex = 8;
            this.lblWrite.Text = "Write";
            // 
            // lblDisplayMode
            // 
            this.lblDisplayMode.AutoSize = true;
            this.lblDisplayMode.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDisplayMode.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDisplayMode.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDisplayMode.Location = new System.Drawing.Point(11, 6);
            this.lblDisplayMode.Name = "lblDisplayMode";
            this.lblDisplayMode.Size = new System.Drawing.Size(94, 17);
            this.lblDisplayMode.TabIndex = 7;
            this.lblDisplayMode.Text = "Display mode :";
            // 
            // chkboxWrite
            // 
            this.chkboxWrite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.chkboxWrite.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.chkboxWrite.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.chkboxWrite.Checked = true;
            this.chkboxWrite.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.chkboxWrite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkboxWrite.ForeColor = System.Drawing.Color.White;
            this.chkboxWrite.Location = new System.Drawing.Point(153, 5);
            this.chkboxWrite.Name = "chkboxWrite";
            this.chkboxWrite.Size = new System.Drawing.Size(20, 20);
            this.chkboxWrite.TabIndex = 0;
            this.chkboxWrite.Click += new System.EventHandler(this.chkboxWrite_Click);
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.bunifuSeparator3.LineThickness = 1;
            this.bunifuSeparator3.Location = new System.Drawing.Point(-5, 0);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(10, 419);
            this.bunifuSeparator3.TabIndex = 2;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = true;
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 4800;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(647, 492);
            this.Controls.Add(this.pnlWindow);
            this.Controls.Add(this.pnlDashBoard);
            this.Controls.Add(this.pnlLeftMenu);
            this.Controls.Add(this.pnlTopMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.pnlTopMenu.ResumeLayout(false);
            this.pnlTopMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            this.pnlLeftMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picIcon)).EndInit();
            this.pnlDashBoard.ResumeLayout(false);
            this.pnlDashBoard.PerformLayout();
            this.pnlControl.ResumeLayout(false);
            this.pnlControl.PerformLayout();
            this.pnlWindow.ResumeLayout(false);
            this.pnlWindow.PerformLayout();
            this.pnlModeDebug.ResumeLayout(false);
            this.pnlModeRead.ResumeLayout(false);
            this.pnlModeWrite.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCode)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopMenu;
        private System.Windows.Forms.Panel pnlLeftMenu;
        private System.Windows.Forms.Panel pnlDashBoard;
        private System.Windows.Forms.Button btnDashboard;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.Button btnControl;
        private System.Windows.Forms.Button btnHelp;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Panel pnlLeftMenuCursor;
        private Bunifu.Framework.UI.BunifuImageButton btnClose;
        private Bunifu.Framework.UI.BunifuImageButton btnMinimize;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private Bunifu.Framework.UI.BunifuCustomLabel lblProgramTitle;
        private System.Windows.Forms.PictureBox picIcon;
        private Bunifu.Framework.UI.BunifuiOSSwitch sliLoadDataFile;
        private Bunifu.Framework.UI.BunifuCustomLabel lblLoadDataFile;
        private Bunifu.Framework.UI.BunifuCustomLabel lblManualEdit;
        private Bunifu.Framework.UI.BunifuiOSSwitch sliManualEdit;
        private Bunifu.Framework.UI.BunifuTileButton btnNew;
        private Bunifu.Framework.UI.BunifuTileButton btnSave;
        private Bunifu.Framework.UI.BunifuTileButton btnOpen;
        private Bunifu.Framework.UI.BunifuTileButton btnDelete;
        private Bunifu.Framework.UI.BunifuTileButton btnEdit;
        private Bunifu.Framework.UI.BunifuTileButton btnAdd;
        private System.Windows.Forms.Panel pnlWindow;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        private Bunifu.Framework.UI.BunifuCheckbox chkboxWrite;
        private Bunifu.Framework.UI.BunifuCustomLabel lblWrite;
        private Bunifu.Framework.UI.BunifuCustomLabel lblDisplayMode;
        private Bunifu.Framework.UI.BunifuCustomLabel lblDebug;
        private Bunifu.Framework.UI.BunifuCheckbox chkboxDebug;
        private Bunifu.Framework.UI.BunifuCustomLabel lblReadMode;
        private Bunifu.Framework.UI.BunifuCheckbox chkboxRead;
        private Bunifu.Framework.UI.BunifuCustomDataGrid dataGridViewCode;
        private System.Windows.Forms.ComboBox cboFile;
        private System.Windows.Forms.Panel pnlControl;
        private Bunifu.Framework.UI.BunifuTileButton btnRead;
        private Bunifu.Framework.UI.BunifuTileButton btnVerify;
        private Bunifu.Framework.UI.BunifuTileButton btnWrite;
        private Bunifu.Framework.UI.BunifuTileButton btnStart;
        private Bunifu.Framework.UI.BunifuTileButton btnDisconnect;
        private Bunifu.Framework.UI.BunifuTileButton btnConnect;
        private Bunifu.Framework.UI.BunifuCustomLabel lblAutoSeq;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator5;
        private Bunifu.Framework.UI.BunifuCustomLabel lblStatus;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtInputBox;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel pnlModeWrite;
        private System.Windows.Forms.ListView listView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Panel pnlModeDebug;
        private System.Windows.Forms.RichTextBox rtbDebug;
        private System.Windows.Forms.Panel pnlModeRead;
        private System.Windows.Forms.RichTextBox txtTaskLog;
    }
}

