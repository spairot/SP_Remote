﻿using System;
using System.Windows.Forms;
using System.IO.Ports; /*For serial port control setting*/

namespace SpecialRemoteGUI
{
    public partial class SettingForm : Form
    {
        public SettingData Setting { get; set; }               // Serial boject class (from SerialPortSetting.cs)
        public SettingForm()
        {
            InitializeComponent();
        }

        private void SettingForm_Load(object sender, EventArgs e)
        {
            pnlSettingLeft.Width = 36;
            pnlSettingSerial.BringToFront();

            /*Initial setting comport get from backup data first*/
            SETTING_SetComPortName();                           // Port name configuration 
            if (BackupData.Baudrate > 0) cmbSettingBaudrate.Text = BackupData.Baudrate.ToString();
            else cmbSettingBaudrate.Text = "4800";              // Baudrate init

            if (BackupData.DataBits > 0) cmbSettingDataBits.Text = BackupData.DataBits.ToString();
            else cmbSettingDataBits.Text = "8";                 // Data Bits init

            if (BackupData.Parity != Parity.None) cmbSettingParity.Text = BackupData.Parity.ToString();
            else cmbSettingParity.Text = "None";                // Parity bits init

            if (BackupData.StopBits != StopBits.None) cmbSettingStopBit.Text = BackupData.StopBits.ToString();
            else cmbSettingStopBit.Text = "One";                // Stop bit init

            if (BackupData.debugModeEnable == true) chbDbgModeEnable.Value = true;
            else chbDbgModeEnable.Value = false;              // Debug mode setting init

            if (BackupData.AutoSeqEnable == true) chkbAutoSeqEna.Value = true;
            else chkbAutoSeqEna.Value = false;                // Auto sequence setting init

            if (BackupData.Write == true) checkedListBox.SetItemCheckState(0, CheckState.Checked);  // 0 : "Write"
            else checkedListBox.SetItemCheckState(0, CheckState.Unchecked);

            if (BackupData.Verify == true) checkedListBox.SetItemCheckState(1, CheckState.Checked); // 1 : "Verify"
            else checkedListBox.SetItemCheckState(1, CheckState.Unchecked);

            if (BackupData.Read == true) checkedListBox.SetItemCheckState(2, CheckState.Checked);   // 2 : "Read"
            else checkedListBox.SetItemCheckState(2, CheckState.Unchecked);
        }

        private void btnSettingClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSettingMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnSettingMenu_Click(object sender, EventArgs e)
        {
            if (pnlSettingLeft.Width == 36)
            {
                pnlSettingLeft.BringToFront();
                pnlSettingLeft.Width = 112;
            }
            else {
                pnlSettingLeft.Width = 36;
            }            
        }

        private void btnSerialPortSetting_Click(object sender, EventArgs e)
        {
            pnlSettingLeft.Width = 36;
            pnlSettingSerial.BringToFront();
        }

        private void btnSettingAuto_Click(object sender, EventArgs e)
        {
            pnlSettingLeft.Width = 36;
            pnlSettingAutoMode.BringToFront();
        }

        private void btnSettingDbg_Click(object sender, EventArgs e)
        {
            pnlSettingLeft.Width = 36;
            pnlSettingDbg.BringToFront();
        }

        /*
        Function : SETTING_SetComPortName
        Detail   : Configuration com port name
        Input    : None
        Output   : None
        History  : 2018-11-10 First written by S.Pairot
        */
        public void SETTING_SetComPortName()
        {
            /*Serial Comport configuration*/
            int PortIndex = -1;
            string ComPortName = null;
            string[] ArrayComPortsNames = null;

            ArrayComPortsNames = System.IO.Ports.SerialPort.GetPortNames();

            try
            {
                do
                {
                    PortIndex += 1;
                    cmbSettingComPort.Items.Add(ArrayComPortsNames[PortIndex]);  // comboBox add found items
                }
                while (!((ArrayComPortsNames[PortIndex] == ComPortName)
                || (PortIndex == ArrayComPortsNames.GetUpperBound(0))));
                Array.Sort(ArrayComPortsNames);

                /*want to get first out*/
                if (PortIndex == ArrayComPortsNames.GetUpperBound(0))
                {
                    ComPortName = ArrayComPortsNames[0];
                }

                if (BackupData.ComPortName != null)                      // comport last selected?
                {                                                        // 
                    cmbSettingComPort.Text = BackupData.ComPortName;     // display last comport select in comboBox
                }                                                        //
                else
                {                                                   //
                    cmbSettingComPort.Text = ArrayComPortsNames[0];      // First item display
                }

            }
            catch (Exception) { };
        }

        /*
        Function : btnSettingOK_Click
        Detail   : Configuration confirm setting
        Input    : object sender, EventArgs e
        Output   : None
        History  : 2018-11-10 First written by S.Pairot
        */
        private void btnSettingOK_Click(object sender, EventArgs e)
        {
            Setting.ComPortName = Convert.ToString(cmbSettingComPort.Text);                    // Port name configuration 
            Setting.Baudrate = Convert.ToInt32(cmbSettingBaudrate.Text);                       // Baudrate configuration
            Setting.DataBits = Convert.ToInt16(cmbSettingDataBits.Text);                       // Data bit configuration
            Setting.Parity = (Parity)Enum.Parse(typeof(Parity), cmbSettingParity.Text);        // Parity configuration
            Setting.StopBits = (StopBits)Enum.Parse(typeof(StopBits), cmbSettingStopBit.Text); // Stop bit configuration
            Setting.debugModeEnable = chbDbgModeEnable.Value;                                  // Debug mode configuration

            Setting.AutoSeqEnable = chkbAutoSeqEna.Value;                                      // Auto sequence setting
            Setting.Write = false;
            Setting.Verify = false;
            Setting.Read = false;
            foreach (string s in checkedListBox.CheckedItems)
            {
                if (s == "Write") Setting.Write = true;
                if (s == "Verify") Setting.Verify = true;
                if (s == "Read") Setting.Read = true;
            }

            this.Close();
        }

        /*
        Function : btnSettingCancel_Click
        Detail   : Configuration cancel
        Input    : object sender, EventArgs e
        Output   : None
        History  : 2018-11-10 First written by S.Pairot
        */
        private void btnSettingCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /*
        Function : btnSettingFindComPort_Click
        Detail   : Re-scan com port name
        Input    : object sender, EventArgs e
        Output   : None
        History  : 2018-11-10 First written by S.Pairot
        */
        private void btnRefreshPort_Click(object sender, EventArgs e)
        {
            cmbSettingComPort.Items.Clear();                  // Clear comport name last store
            SETTING_SetComPortName();                         // Call main form for re-scan com port change
        }

        private void chkbAutoSeqEna_OnValueChange(object sender, EventArgs e)
        {
            if (chkbAutoSeqEna.Value == true) checkedListBox.Enabled = true;
            else checkedListBox.Enabled = false;
        }
    }
}
/*----------------------------------EOF-----------------------------------*/
