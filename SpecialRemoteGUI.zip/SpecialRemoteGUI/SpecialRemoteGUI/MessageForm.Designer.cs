﻿namespace SpecialRemoteGUI
{
    partial class Message
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Message));
            this.lblShortMessage = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblMessageTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.btnMessageIcon = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnMessageIconInfo = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.btnMessageClose = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnMessageIconError = new Bunifu.Framework.UI.BunifuImageButton();
            ((System.ComponentModel.ISupportInitialize)(this.btnMessageIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMessageIconInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMessageClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMessageIconError)).BeginInit();
            this.SuspendLayout();
            // 
            // lblShortMessage
            // 
            this.lblShortMessage.AutoSize = true;
            this.lblShortMessage.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShortMessage.ForeColor = System.Drawing.Color.White;
            this.lblShortMessage.Location = new System.Drawing.Point(60, 54);
            this.lblShortMessage.Name = "lblShortMessage";
            this.lblShortMessage.Size = new System.Drawing.Size(147, 17);
            this.lblShortMessage.TabIndex = 13;
            this.lblShortMessage.Text = "Message or information";
            // 
            // lblMessageTitle
            // 
            this.lblMessageTitle.AutoSize = true;
            this.lblMessageTitle.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessageTitle.ForeColor = System.Drawing.Color.White;
            this.lblMessageTitle.Location = new System.Drawing.Point(99, 13);
            this.lblMessageTitle.Name = "lblMessageTitle";
            this.lblMessageTitle.Size = new System.Drawing.Size(56, 16);
            this.lblMessageTitle.TabIndex = 14;
            this.lblMessageTitle.Text = "Message";
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this;
            this.bunifuDragControl1.Vertical = true;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.bunifuSeparator1.LineThickness = 2;
            this.bunifuSeparator1.Location = new System.Drawing.Point(4, 107);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(245, 14);
            this.bunifuSeparator1.TabIndex = 15;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // btnMessageIcon
            // 
            this.btnMessageIcon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnMessageIcon.Image = ((System.Drawing.Image)(resources.GetObject("btnMessageIcon.Image")));
            this.btnMessageIcon.ImageActive = null;
            this.btnMessageIcon.Location = new System.Drawing.Point(22, 48);
            this.btnMessageIcon.Name = "btnMessageIcon";
            this.btnMessageIcon.Size = new System.Drawing.Size(30, 30);
            this.btnMessageIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.btnMessageIcon.TabIndex = 17;
            this.btnMessageIcon.TabStop = false;
            this.btnMessageIcon.Zoom = 10;
            // 
            // btnMessageIconInfo
            // 
            this.btnMessageIconInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnMessageIconInfo.Image = ((System.Drawing.Image)(resources.GetObject("btnMessageIconInfo.Image")));
            this.btnMessageIconInfo.ImageActive = null;
            this.btnMessageIconInfo.Location = new System.Drawing.Point(22, 48);
            this.btnMessageIconInfo.Name = "btnMessageIconInfo";
            this.btnMessageIconInfo.Size = new System.Drawing.Size(30, 30);
            this.btnMessageIconInfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnMessageIconInfo.TabIndex = 18;
            this.btnMessageIconInfo.TabStop = false;
            this.btnMessageIconInfo.Zoom = 10;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(0)))));
            this.bunifuSeparator2.LineThickness = 2;
            this.bunifuSeparator2.Location = new System.Drawing.Point(3, -1);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(245, 11);
            this.bunifuSeparator2.TabIndex = 19;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // btnMessageClose
            // 
            this.btnMessageClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnMessageClose.Image = ((System.Drawing.Image)(resources.GetObject("btnMessageClose.Image")));
            this.btnMessageClose.ImageActive = null;
            this.btnMessageClose.Location = new System.Drawing.Point(220, 11);
            this.btnMessageClose.Name = "btnMessageClose";
            this.btnMessageClose.Size = new System.Drawing.Size(25, 25);
            this.btnMessageClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnMessageClose.TabIndex = 20;
            this.btnMessageClose.TabStop = false;
            this.btnMessageClose.Zoom = 10;
            this.btnMessageClose.Click += new System.EventHandler(this.btnMessageClose_Click_1);
            // 
            // btnMessageIconError
            // 
            this.btnMessageIconError.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnMessageIconError.Image = ((System.Drawing.Image)(resources.GetObject("btnMessageIconError.Image")));
            this.btnMessageIconError.ImageActive = null;
            this.btnMessageIconError.Location = new System.Drawing.Point(22, 48);
            this.btnMessageIconError.Name = "btnMessageIconError";
            this.btnMessageIconError.Size = new System.Drawing.Size(30, 30);
            this.btnMessageIconError.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnMessageIconError.TabIndex = 21;
            this.btnMessageIconError.TabStop = false;
            this.btnMessageIconError.Zoom = 10;
            // 
            // Message
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(251, 118);
            this.Controls.Add(this.btnMessageIconError);
            this.Controls.Add(this.btnMessageClose);
            this.Controls.Add(this.bunifuSeparator2);
            this.Controls.Add(this.btnMessageIconInfo);
            this.Controls.Add(this.lblShortMessage);
            this.Controls.Add(this.btnMessageIcon);
            this.Controls.Add(this.bunifuSeparator1);
            this.Controls.Add(this.lblMessageTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Message";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Message";
            this.Load += new System.EventHandler(this.Message_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btnMessageIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMessageIconInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMessageClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMessageIconError)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Bunifu.Framework.UI.BunifuCustomLabel lblShortMessage;
        private Bunifu.Framework.UI.BunifuCustomLabel lblMessageTitle;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.Framework.UI.BunifuImageButton btnMessageIcon;
        private Bunifu.Framework.UI.BunifuImageButton btnMessageIconInfo;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private Bunifu.Framework.UI.BunifuImageButton btnMessageClose;
        private Bunifu.Framework.UI.BunifuImageButton btnMessageIconError;
    }
}